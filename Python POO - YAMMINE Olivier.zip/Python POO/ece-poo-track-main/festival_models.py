"""Compatibility exports for the festival domain models.
The domain classes are implemented in festival.py.
"""

from festival import (
    Artist,
    Festival,
    Lineup,
    Performance,
    SoloShow,
    Venue,
    Workshop,
)

__all__ = [
    "Artist",
    "Festival",
    "Lineup",
    "Performance",
    "SoloShow",
    "Venue",
    "Workshop",
]
