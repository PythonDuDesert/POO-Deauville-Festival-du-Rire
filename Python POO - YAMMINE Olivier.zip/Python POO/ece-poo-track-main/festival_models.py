import json
import unicodedata
from datetime import date, datetime, timedelta
from pathlib import Path

DAY_CHANGE = 6

DATA_FILE = Path(__file__).parent / "data" / "festival.json"

# Bloc 3
class Venue:
    def __init__(self, name, slug, capacity, address):
        self.name = name
        self.slug = slug
        self.capacity = capacity
        self.address = address

class Artist:
    def __init__(self, name, slug, bio, photo_url):
        self.name = name
        self.slug = slug
        self.bio = bio
        self.photo_url = photo_url

class Performance:
    def __init__(self, id, kind, title, venue, start, duration_minutes, description, artist=None, min_age=None, host=None, acts=None, teacher=None, participants=None, max_participants=None):
        self.id = id
        self.kind = kind
        self.title = title
        self.venue = venue
        self.start = datetime.fromisoformat(start)
        self.duration_minutes = duration_minutes
        self.description = description
        self.artist = artist
        self.min_age = min_age
        self.host = host
        self.acts = acts if acts is not None else []
        self.teacher = teacher
        self.participants = participants if participants is not None else []
        self.max_participants = max_participants

    @property
    def end(self):
        return self.start + timedelta(minutes=self.duration_minutes)

    @property
    def festival_day(self):
        return (self.start.date() if self.start.hour >= DAY_CHANGE else self.start.date() - timedelta(days=1))

    def involves(self, artist):
        if self.kind == "solo":
            return self.artist.slug == artist.slug
        elif self.kind == "lineup":
            return self.host.slug == artist.slug or any(act.slug == artist.slug for act in self.acts)
        else:
            return self.teacher.slug == artist.slug

    def to_view(self):
        if self.kind == "solo":
            artists = [self.artist]
        elif self.kind == "lineup":
            artists = [self.host] + self.acts
        elif self.kind == "workshop":
            artists = [self.teacher]
        else:
            artists = []
        if self.kind == "solo":
            summary = f"with {self.artist.name}"
        elif self.kind == "lineup":
            act_names = ", ".join(act.name for act in self.acts)
            summary = f"hosted by {self.host.name}, with {act_names}"
        elif self.kind == "workshop":
            summary = f"with {self.teacher.name}"
        else:
            summary = ""
        result = { # Commun
            "id": self.id,
            "kind": self.kind,
            "title": self.title,
            "venue": self.venue.slug,
            "venue_name": self.venue.name,
            "festival_day": self.festival_day.isoformat(),
            "start": self.start.isoformat(timespec="minutes"),
            "end": self.end.isoformat(timespec="minutes"),
            "duration_minutes": self.duration_minutes,
            "description": self.description,
            "summary": summary,
            "capacity": (self.max_participants if self.kind == "workshop" else self.venue.capacity),
            "artists": [
                {"slug": artist.slug, "name": artist.name}
                for artist in artists
            ],
        }

        # Champs "optionnels", remplis selon lse cas
        if self.kind == "solo":
            result["artist"] = self.artist.slug
            result["min_age"] = self.min_age
        elif self.kind == "lineup":
            result["host"] = self.host.slug
            result["acts"] = [artist.slug for artist in self.acts]
        else:
            if self.max_participants is not None:
                result["places_left"] = max(0, self.max_participants - len(self.participants))
            else:
                result["places_left"] = None

        return result


class Festival:
    def __init__(self, name, first_day, last_day, venues=None, artists=None, performances=None):
        self.name = name
        self.first_day = (date.fromisoformat(first_day) if isinstance(first_day, str) else first_day)
        self.last_day = (date.fromisoformat(last_day) if isinstance(last_day, str) else last_day)
        self._venues = venues if venues is not None else []
        self._artists = artists if artists is not None else []
        self._performances = performances if performances is not None else []

    def get_venue(self, slug):
        return next(
            (venue for venue in self._venues if venue.slug == slug),
            None
        )

    def get_artist(self, slug):
        return next(
            (artist for artist in self._artists if artist.slug == slug),
            None
        )

    def get_performance(self, performance_id):
        return next(
            (performance for performance in self._performances if performance.id == performance_id),
            None
        )

    def program_for_day(self, day, venue_slug=None):
        if isinstance(day, str):
            day = datetime.fromisoformat(day).date()
        performances = [performance for performance in self._performances if performance.festival_day == day]
        if venue_slug is not None:
            performances = [performance for performance in performances if performance.venue.slug == venue_slug]
        return sorted(performances, key=lambda performance: performance.start)

    def performances_artiste(self, artist_slug):
        artist = self.get_artist(artist_slug)
        if artist is None:
            return []
        performances = [performance for performance in self._performances if performance.involves(artist)]
        return sorted(performances, key=lambda performance: performance.start)

    def now_playing(self, at=None):
        if at is None:
            at = datetime.now()
        elif isinstance(at, str):
            at = datetime.fromisoformat(at)
        return sorted([performance for performance in self._performances if performance.start <= at < performance.end],key=lambda performance: performance.start)

    def up_next(self, at=None, limit=3):
        if at is None:
            at = datetime.now()
        elif isinstance(at, str):
            at = datetime.fromisoformat(at)
        performances = [performance for performance in self._performances if performance.start > at]
        performances.sort(key=lambda performance: performance.start)
        return performances[:limit]

    def has_time_conflict(self, first, second):
        return (first.start < second.end and second.start < first.end)

    def artists_in(self, performance):
        if performance.kind == "solo":
            return {performance.artist.slug}
        elif performance.kind == "lineup":
            return {performance.host.slug, *(artist.slug for artist in performance.acts)}
        elif performance.kind == "workshop":
            return {performance.teacher.slug}
        return set()

    def check_performance_conflicts(self, candidate, exclude=None):
        candidate_artists = self.artists_in(candidate)
        for existing in self._performances:
            if existing is exclude:
                continue
            if not self.has_time_conflict(candidate, existing):
                continue
            if candidate.venue.slug == existing.venue.slug:
                raise ValueError("Venue is already occupied.")
            existing_artists = self.artists_in(existing)
            if candidate_artists & existing_artists:
                raise ValueError("An artist is already busy.")

    def validate_duration(self, performance):
        duration = (performance.end - performance.start).total_seconds() / 60
        if duration < 1 or duration > 360:
            raise ValueError("Duration must be between 1 and 360 minutes.")

    def validate_festival_dates(self, performance):
        day = performance.festival_day
        if day < self.first_day or day > self.last_day:
            raise ValueError("Performance date is outside the festival dates.")

    def validate_performance(self, performance, exclude=None):
        self.validate_performance_type(performance)
        self.validate_duration(performance)
        self.validate_festival_dates(performance)
        self.check_performance_conflicts(performance, exclude)

    def validate_performance_type(self, performance):
        if performance.kind not in ("solo", "lineup", "workshop"):
            raise ValueError("Invalid performance type.")

        if performance.kind == "solo" and performance.artist is None:
            raise ValueError("A solo performance requires an artist.")

        if performance.kind == "lineup":
            if performance.host is None:
                raise ValueError("A lineup requires a host.")
            if len(performance.acts) < 2:
                raise ValueError("A lineup requires at least two acts.")

        if performance.kind == "workshop":
            if performance.teacher is None:
                raise ValueError("A workshop requires a teacher.")
            if (performance.max_participants is None or performance.max_participants <= 0):
                raise ValueError("A workshop requires a positive participant limit.")

    def add_performance(self, performance):
        self.validate_performance(performance)
        self._performances.append(performance)

    def update_performance(self, performance_id, updated_performance):
        existing = self.get_performance(performance_id)
        if existing is None:
            raise ValueError("Performance not found.")
        self.validate_performance(updated_performance, exclude=existing)
        index = self._performances.index(existing)
        self._performances[index] = updated_performance

    def cancel_performance(self, performance_id):
        performance = self.get_performance(performance_id)
        if performance is None:
            raise ValueError("Performance not found.")
        self._performances.remove(performance)





def create_performance_id(venue, start):
    start_datetime = datetime.fromisoformat(start)
    date = start_datetime.strftime("%Y-%m-%d")
    time = start_datetime.strftime("%H%M")
    return f"{venue.slug}-{date}-{time}"

def load_festival():
    with DATA_FILE.open(encoding="utf-8") as file:
        festival = json.load(file)

    venues = [
        Venue(
            name=venue["name"],
            slug=name_to_slug(venue["name"]),
            capacity=venue["capacity"],
            address=venue["address"]
        )
        for venue in festival["venues"]
    ]

    artists = [
        Artist(
            name=artist["name"],
            slug=name_to_slug(artist["name"]),
            bio=artist["bio"],
            photo_url=artist["photo_url"]
        )
        for artist in festival["artists"]
    ]

    venues_by_slug = {venue.slug: venue for venue in venues}
    artists_by_slug = {artist.slug: artist for artist in artists}
    performances = []
    for perf in festival["performances"]:
        venue = venues_by_slug[perf["venue"]]
        if perf["kind"] == "solo":
            performance = Performance(
                id=create_performance_id(venue, perf["start"]),
                kind=perf["kind"],
                title=perf["title"],
                venue=venue,
                start=perf["start"],
                duration_minutes=perf["duration_minutes"],
                description=perf["description"],
                artist=artists_by_slug[perf["artist"]],
                min_age=perf["min_age"]
            )
        elif perf["kind"] == "lineup":
            performance = Performance(
                id=create_performance_id(venue, perf["start"]),
                kind=perf["kind"],
                title=perf["title"],
                venue=venue,
                start=perf["start"],
                duration_minutes=perf["duration_minutes"],
                description=perf["description"],
                host=artists_by_slug[perf["host"]],
                acts=[
                    artists_by_slug[slug]
                    for slug in perf["acts"]
                ]
            )
        elif perf["kind"] == "workshop":
            performance = Performance(
                id=create_performance_id(venue, perf["start"]),
                kind=perf["kind"],
                title=perf["title"],
                venue=venue,
                start=perf["start"],
                duration_minutes=perf["duration_minutes"],
                description=perf["description"],
                teacher=artists_by_slug[perf["teacher"]],
                participants=perf["participants"],
                max_participants=perf["max_participants"]
            )
        performances.append(performance)

    return Festival(
        name=festival["name"],
        first_day=festival["first_day"],
        last_day=festival["last_day"],
        venues=venues,
        artists=artists,
        performances=performances
    )


def name_to_slug(name):
    decomposed = unicodedata.normalize("NFKD", name)
    slug_name = decomposed.encode("ascii", "ignore").decode("ascii")
    result = ""
    for char in slug_name.lower():
        if char.isalnum():
            result += char
        elif not result.endswith("-"):
            result += "-"
    return result

def slug_to_name(name):
    return name.replace("-", " ").strip().title()


festival = load_festival()