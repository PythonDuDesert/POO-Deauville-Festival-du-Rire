"""Compatibilité avec le module de modèles utilisé à l'étape E10."""
from festival import (
    Artist, Festival, FestivalConflict, FestivalError, FestivalInvalid,
    FestivalNotFound, Lineup, Performance, SoloShow, Venue, Workshop,
    create_performance_id, load_festival, name_to_slug, slug_to_name,
)
