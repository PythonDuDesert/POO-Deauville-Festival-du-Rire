"""Festival API: application factory, business rules, and injectable storage."""
from __future__ import annotations

import copy
from datetime import date, datetime, time, timedelta
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, model_validator

from festival import (
    Artist,
    Festival,
    FestivalError,
    FestivalInvalid,
    FestivalNotFound,
    Lineup,
    SoloShow,
    Workshop,
    load_festival,
    name_to_slug as _domain_name_to_slug,
)
from storage import JsonStorage, Storage

PROJECT_DIRECTORY = Path(__file__).resolve().parent
DATA_FILE = PROJECT_DIRECTORY / "data" / "festival.json"
WEB_DIRECTORY = PROJECT_DIRECTORY / "web" / "public"
ADMIN_DIRECTORY = PROJECT_DIRECTORY / "web" / "admin"


class ArtistCreate(BaseModel):
    name: str
    bio: str = ""
    photo_url: str = ""


class PerformanceCreate(BaseModel):
    kind: str
    title: str
    venue: str
    start: datetime
    duration_minutes: int
    description: str = ""
    artist: str | None = None
    min_age: int | None = None
    host: str | None = None
    acts: list[str] = Field(default_factory=list)
    teacher: str | None = None
    max_participants: int | None = None
    participants: list[str] | None = None

    @model_validator(mode="after")
    def validate_kind_fields(self):
        required_by_kind = {
            "solo": ("artist",),
            "lineup": ("host", "acts"),
            "workshop": ("teacher", "max_participants"),
        }
        for field in required_by_kind.get(self.kind, ()):
            if field not in self.model_fields_set or getattr(self, field) is None:
                raise ValueError(f"Field '{field}' is required for a {self.kind} performance.")
        return self


class ParticipantCreate(BaseModel):
    name: str


def name_to_slug(name: str) -> str:
    """Use the same slug rules as the domain model."""
    return _domain_name_to_slug(name)


def get_festival_day(start: datetime) -> str:
    """Events before 06:00 belong to the previous festival evening."""
    day = start.date()
    if start.time() < time(6, 0):
        day -= timedelta(days=1)
    return day.isoformat()


def get_performance_id(venue_slug: str, start: datetime) -> str:
    return f"{venue_slug}-{start:%Y-%m-%d-%H%M}"


def _build_performance_object(data: dict[str, Any], item: dict[str, Any]):
    model = load_festival(data)
    venue = model.get_venue(item["venue"])
    if venue is None:
        raise FestivalNotFound("Unknown venue.")

    kind = item["kind"]
    start = datetime.fromisoformat(item["start"])
    common = {
        "id": get_performance_id(item["venue"], start),
        "title": item["title"],
        "venue": venue,
        "start": start,
        "duration_minutes": item["duration_minutes"],
        "description": item.get("description", ""),
    }

    def get_artist(slug: str | None):
        artist = model.get_artist(slug) if slug else None
        if artist is None:
            raise FestivalNotFound("Unknown artist.")
        return artist

    if kind == "solo":
        return SoloShow(**common, artist=get_artist(item.get("artist")), min_age=item.get("min_age", 0) if item.get("min_age") is not None else 0)
    if kind == "lineup":
        host = get_artist(item.get("host"))
        acts = [get_artist(slug) for slug in item.get("acts", [])]
        return Lineup(**common, host=host, acts=acts)
    if kind == "workshop":
        return Workshop(
            **common,
            teacher=get_artist(item.get("teacher")),
            max_participants=item.get("max_participants"),
            participants=item.get("participants", []),
        )
    raise FestivalInvalid("Invalid performance kind.")


def _saved_item(body: PerformanceCreate, *, existing: dict[str, Any] | None = None) -> dict[str, Any]:
    item = body.model_dump(mode="json", exclude_none=True)
    # The API contract stores fields for the selected performance kind only.
    kind_fields = {
        "solo": {"artist", "min_age"},
        "lineup": {"host", "acts"},
        "workshop": {"teacher", "max_participants", "participants"},
    }
    for field in ("artist", "min_age", "host", "acts", "teacher", "max_participants", "participants"):
        if field not in kind_fields.get(item["kind"], set()):
            item.pop(field, None)
    if item["kind"] == "workshop":
        item["participants"] = copy.deepcopy((existing or {}).get("participants", item.get("participants", [])))
    return item


class _AppState:
    def __init__(self, storage: Storage):
        self.storage = storage
        self.data: dict[str, Any] | None = None
        self.model: Festival | None = None

    def ensure_loaded(self) -> tuple[dict[str, Any], Festival]:
        if self.data is None or self.model is None:
            try:
                loaded = self.storage.load()
                model = load_festival(loaded)
            except Exception as exc:
                raise HTTPException(status_code=500, detail="The festival data file could not be read.") from exc
            self.data = loaded
            self.model = model
        return self.data, self.model

    def rebuild_model(self) -> Festival:
        data, _ = self.ensure_loaded()
        self.model = load_festival(data)
        return self.model

    def save(self) -> None:
        data, _ = self.ensure_loaded()
        try:
            self.storage.save(data)
        except Exception as exc:
            raise HTTPException(status_code=500, detail="The festival data file could not be written.") from exc


def create_app(data_storage: Storage | None = None) -> FastAPI:
    """Build an isolated application around the supplied storage backend."""
    state = _AppState(data_storage or JsonStorage(DATA_FILE))
    application = FastAPI(
        title="Festival API",
        description="API du festival : informations, artistes et lieux.",
        version="1.0.0",
    )

    @application.exception_handler(FestivalError)
    async def festival_error_handler(request: Request, exc: FestivalError):
        return JSONResponse(status_code=exc.status_code, content={"detail": str(exc)})

    @application.get("/api/festival")
    def get_festival():
        data, _ = state.ensure_loaded()
        first_day = date.fromisoformat(data["first_day"])
        last_day = date.fromisoformat(data["last_day"])
        days = []
        current = first_day
        while current <= last_day:
            days.append(current.isoformat())
            current += timedelta(days=1)
        return {"name": data["name"], "first_day": data["first_day"], "last_day": data["last_day"], "days": days}

    @application.get("/api/venues")
    def get_venues():
        data, _ = state.ensure_loaded()
        return [{"slug": name_to_slug(v["name"]), "name": v["name"], "capacity": v["capacity"], "address": v["address"]} for v in data["venues"]]

    @application.get("/api/artists")
    def get_artists():
        _, model = state.ensure_loaded()
        return [{"slug": a.slug, "name": a.name, "bio": a.bio, "photo_url": a.photo_url} for a in sorted(model.artists, key=lambda a: a.name.casefold())]

    @application.get("/api/artists/{slug}")
    def get_artist(slug: str):
        _, model = state.ensure_loaded()
        artist = model.get_artist(slug)
        if artist is None:
            raise FestivalNotFound("Unknown artist.")
        performances = model.performances_artiste(slug)
        return {"slug": artist.slug, "name": artist.name, "bio": artist.bio, "photo_url": artist.photo_url, "performances": [p.to_view() for p in performances]}

    @application.post("/api/artists", status_code=201)
    def create_artist(artist: ArtistCreate):
        data, model = state.ensure_loaded()
        name = artist.name.strip()
        if not name:
            raise FestivalInvalid("Artist name cannot be empty.")
        slug = name_to_slug(name)
        new_artist = {"name": name, "bio": artist.bio.strip(), "photo_url": artist.photo_url.strip()}
        model.add_artist(Artist(name=name, slug=slug, bio=new_artist["bio"], photo_url=new_artist["photo_url"]))
        data["artists"].append(new_artist)
        try:
            state.save()
        except HTTPException:
            data["artists"].pop()
            state.rebuild_model()
            raise
        state.rebuild_model()
        return {"slug": slug, **new_artist}

    @application.get("/api/programme")
    def get_programme(day: date | None = None, venue: str | None = None):
        _, model = state.ensure_loaded()
        if venue is not None and model.get_venue(venue) is None:
            raise FestivalNotFound("Unknown venue.")
        performances = model.performances
        if day is not None:
            performances = [p for p in performances if p.festival_day == day]
        if venue is not None:
            performances = [p for p in performances if p.venue.slug == venue]
        return [p.to_view() for p in sorted(performances, key=lambda p: p.start)]

    @application.post("/api/performances", status_code=201)
    def create_performance(performance: PerformanceCreate):
        data, model = state.ensure_loaded()
        item = _saved_item(performance)
        candidate = _build_performance_object(data, item)
        model.add_performance(candidate)
        data["performances"].append(item)
        try:
            state.save()
        except HTTPException:
            data["performances"].pop()
            state.rebuild_model()
            raise
        state.rebuild_model()
        created = state.model.get_performance(candidate.id)
        return created.to_view()

    @application.put("/api/performances/{performance_id}")
    def update_performance(performance_id: str, performance: PerformanceCreate):
        data, model = state.ensure_loaded()
        index = next((i for i, item in enumerate(data["performances"]) if get_performance_id(item["venue"], datetime.fromisoformat(item["start"])) == performance_id), None)
        if index is None:
            raise FestivalNotFound("Unknown performance.")
        existing_item = data["performances"][index]
        updated = _saved_item(performance, existing=existing_item)
        candidate = _build_performance_object(data, updated)
        # This validates before changing either representation; failures are atomic.
        model.update_performance(performance_id, candidate)
        data["performances"][index] = updated
        try:
            state.save()
        except HTTPException:
            data["performances"][index] = existing_item
            state.rebuild_model()
            raise
        state.rebuild_model()
        return state.model.get_performance(candidate.id).to_view()

    @application.delete("/api/performances/{performance_id}", status_code=204)
    def delete_performance(performance_id: str):
        data, model = state.ensure_loaded()
        index = next((i for i, item in enumerate(data["performances"]) if get_performance_id(item["venue"], datetime.fromisoformat(item["start"])) == performance_id), None)
        if index is None or model.get_performance(performance_id) is None:
            raise FestivalNotFound("Unknown performance.")
        removed = data["performances"].pop(index)
        model.cancel_performance(performance_id)
        try:
            state.save()
        except HTTPException:
            data["performances"].insert(index, removed)
            state.rebuild_model()
            raise
        state.rebuild_model()
        return None

    @application.get("/api/performances/{performance_id}")
    def get_performance(performance_id: str):
        _, model = state.ensure_loaded()
        performance = model.get_performance(performance_id)
        if performance is None:
            raise FestivalNotFound("Unknown performance.")
        return performance.to_view()

    @application.post("/api/performances/{performance_id}/participants", status_code=201)
    def register_participant(performance_id: str, participant: ParticipantCreate):
        data, model = state.ensure_loaded()
        performance = model.get_performance(performance_id)
        if performance is None:
            raise FestivalNotFound("Unknown performance.")
        if not isinstance(performance, Workshop):
            raise FestivalInvalid("This performance is not a workshop.")
        index = next((i for i, item in enumerate(data["performances"]) if get_performance_id(item["venue"], datetime.fromisoformat(item["start"])) == performance_id), None)
        if index is None:
            raise FestivalNotFound("Unknown performance.")
        name = participant.name.strip()
        performance.register_participant(name)
        data["performances"][index].setdefault("participants", []).append(name)
        try:
            state.save()
        except HTTPException:
            data["performances"][index]["participants"].pop()
            state.rebuild_model()
            raise
        state.rebuild_model()
        return state.model.get_performance(performance_id).to_view()

    @application.get("/api/now")
    def get_now(at: datetime | None = None):
        _, model = state.ensure_loaded()
        moment = at if at is not None else datetime.now()
        return {"at": moment.isoformat(timespec="minutes"), "now_playing": [p.to_view() for p in model.now_playing(moment)[:3]], "up_next": [p.to_view() for p in model.up_next(moment, limit=3)]}

    application.mount("/admin", StaticFiles(directory=ADMIN_DIRECTORY, html=True), name="admin")
    application.mount("/", StaticFiles(directory=WEB_DIRECTORY, html=True), name="public")
    return application


# Uvicorn-compatible default application. Each create_app() call gets its own state.
app = create_app()
