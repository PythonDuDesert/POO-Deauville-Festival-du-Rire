import json
import unicodedata
from datetime import date, datetime, time, timedelta
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from festival_models import load_festival

DATA_FILE = Path(__file__).parent / "data" / "festival.json"
with DATA_FILE.open(encoding="utf-8") as file:
    festival = json.load(file)

festival_objects = load_festival()


class ArtistCreate(BaseModel):
    name: str
    bio: str = ""
    photo_url: str = ""

class PerformanceCreate(BaseModel):
    kind: str
    title: str
    venue: str
    start: datetime
    duration_minutes: int
    description: str = ""

    # Champs spécifiques selon le type
    artist: str | None = None
    min_age: int | None = None
    host: str | None = None
    acts: list[str] = []
    teacher: str | None = None
    max_participants: int | None = None

class ParticipantCreate(BaseModel):
    name: str


def name_to_slug(name: str) -> str:
    name = unicodedata.normalize("NFKD", name)
    name = "".join(char for char in name if not unicodedata.combining(char))
    return name.casefold().replace(" ", "-")

def get_venues_by_slug():
    return {
        name_to_slug(venue["name"]): venue
        for venue in festival["venues"]
    }

def get_artists_by_slug():
    return {
        name_to_slug(artist["name"]): artist
        for artist in festival["artists"]
    }

def get_festival_day(start):
    # Les événements avant 06 h appartiennent à la soirée précédente.
    day = start.date()
    if start.time() < time(6, 0):
        day -= timedelta(days=1)
    return day.isoformat()

def get_performance_id(venue_slug, start):
    return f"{venue_slug}-{start:%Y-%m-%d-%H%M}"

def build_performance(item):
    venues = get_venues_by_slug()
    artists_by_slug = get_artists_by_slug()
    venue_slug = item["venue"]
    venue = venues.get(venue_slug)

    if venue is None:
        raise HTTPException(status_code=404, detail="Unknown venue.")

    start = datetime.fromisoformat(item["start"])
    end = start + timedelta(minutes=item["duration_minutes"])
    kind = item["kind"]
    if kind == "solo":
        artist_slugs = [item["artist"]]
    elif kind == "lineup":
        artist_slugs = [item["host"], *item["acts"]]
    elif kind == "workshop":
        artist_slugs = [item["teacher"]]
    else:
        raise HTTPException(status_code=422, detail="Invalid performance kind.")

    # Vérifier que tous les artistes existent avant de les utiliser.
    for slug in artist_slugs:
        if slug not in artists_by_slug:
            raise HTTPException(status_code=404, detail=f"Unknown artist: {slug}.")

    # Construire le résumé après les vérifications.
    if kind == "solo":
        summary = f"with {artists_by_slug[item['artist']]['name']}"
    elif kind == "lineup":
        host = artists_by_slug[item["host"]]["name"]
        acts = ", ".join(artists_by_slug[slug]["name"] for slug in item["acts"])
        summary = f"hosted by {host}, with {acts}"
    else:  # workshop
        teacher = artists_by_slug[item["teacher"]]["name"]
        summary = f"with {teacher}"

    # Vérifier que tous les artistes existent.
    for slug in artist_slugs:
        if slug not in artists_by_slug:
            raise HTTPException(status_code=404, detail=f"Unknown artist: {slug}.")

    artists = [
        {"slug": slug, "name": artists_by_slug[slug]["name"]}
        for slug in artist_slugs
    ]

    result = {
        "id": get_performance_id(venue_slug, start),
        "kind": kind,
        "title": item["title"],
        "venue": venue_slug,
        "venue_name": venue["name"],
        "start": start.isoformat(timespec="minutes"),
        "end": end.isoformat(timespec="minutes"),
        "duration_minutes": item["duration_minutes"],
        "festival_day": get_festival_day(start),
        "description": item.get("description", ""),
        "summary": summary,
        "capacity": (item["max_participants"] if kind == "workshop" else venue["capacity"]),
        "artists": artists,
    }

    # Ajouter les champs spécifiques au type.
    for field in ("artist", "min_age", "host", "acts", "teacher", "max_participants", "participants"):
        if field in item:
            result[field] = item[field]

    if kind == "workshop":
        result["places_left"] = max(0, item["max_participants"] - len(item.get("participants", [])),)

    return result

def get_all_performances():
    performances = [build_performance(item) for item in festival["performances"]]
    return sorted(performances, key=lambda item: item["start"])

def check_performance_conflicts(candidate, exclude=None):
    """Vérifie les conflits de lieu et d'artistes."""

    candidate_start = datetime.fromisoformat(candidate["start"])
    candidate_end = candidate_start + timedelta(minutes=candidate["duration_minutes"])
    candidate_artists = set()

    if candidate["kind"] == "solo":
        candidate_artists.add(candidate["artist"])

    elif candidate["kind"] == "lineup":
        candidate_artists.add(candidate["host"])
        candidate_artists.update(candidate["acts"])

    elif candidate["kind"] == "workshop":
        candidate_artists.add(candidate["teacher"])

    for existing in festival["performances"]:
        # Ignorer la performance en cours de modification.
        if existing is exclude:
            continue

        existing_start = datetime.fromisoformat(existing["start"])
        existing_end = existing_start + timedelta(minutes=existing["duration_minutes"])

        # Les performances ne se chevauchent pas si l'une finit
        # exactement au moment où l'autre commence.
        overlaps = (candidate_start < existing_end and existing_start < candidate_end)
        if not overlaps:
            continue

        # Conflit si le lieu est déjà occupé.
        if candidate["venue"] == existing["venue"]:
            raise HTTPException(status_code=409, detail="Venue is already occupied.")

        # Identifier les artistes de la performance existante.
        existing_artists = set()

        if existing["kind"] == "solo":
            existing_artists.add(existing["artist"])

        elif existing["kind"] == "lineup":
            existing_artists.add(existing["host"])
            existing_artists.update(existing["acts"])

        elif existing["kind"] == "workshop":
            existing_artists.add(existing["teacher"])

        if candidate_artists & existing_artists:
            raise HTTPException(status_code=409, detail="An artist is already busy.")


def check_festival_dates(item):
    """Vérifie que la performance appartient aux dates du festival."""
    start = datetime.fromisoformat(item["start"])
    festival_day = date.fromisoformat(get_festival_day(start))
    first_day = date.fromisoformat(festival["first_day"])
    last_day = date.fromisoformat(festival["last_day"])
    if not first_day <= festival_day <= last_day:
        raise HTTPException(status_code=409, detail="Performance date is outside the festival.")


# --------------------------------------------------
# Application FastAPI
# --------------------------------------------------
app = FastAPI(title="Festival API", description="API du festival : informations, artistes et lieux.", version="1.0.0")


# --------------------------------------------------
# GET /api/festival
# --------------------------------------------------
@app.get("/api/festival")
def get_festival():
    """Retourne les informations générales du festival et ses dates."""
    first_day = date.fromisoformat(festival["first_day"])
    last_day = date.fromisoformat(festival["last_day"])
    days = []
    current_day = first_day
    while current_day <= last_day:
        days.append(current_day.isoformat())
        current_day += timedelta(days=1)

    return {
        "name": festival["name"],
        "first_day": festival["first_day"],
        "last_day": festival["last_day"],
        "days": days,
    }


# --------------------------------------------------
# GET /api/venues
# --------------------------------------------------
@app.get("/api/venues")
def get_venues():
    """Retourne les lieux dans leur ordre d'origine."""
    return [
        {
            "slug": name_to_slug(venue["name"]),
            "name": venue["name"],
            "capacity": venue["capacity"],
            "address": venue["address"],
        }
        for venue in festival["venues"]
    ]


# --------------------------------------------------
# GET /api/artists
# --------------------------------------------------
@app.get("/api/artists")
def get_artists():
    """Retourne la liste des artistes du festival."""
    return [
        {
            "slug": artist.slug,
            "name": artist.name,
            "bio": artist.bio,
            "photo_url": artist.photo_url,
        }
        for artist in festival_objects._artists
    ]


# --------------------------------------------------
# GET /api/artists
# --------------------------------------------------
@app.get("/api/artists/{slug}")
def get_artist(slug: str):
    artist = festival_objects.get_artist(slug)
    if artist is None:
        raise HTTPException(status_code=404, detail="Unknown artist.")
    performances = festival_objects.performances_artiste(slug)
    return {
        "slug": artist.slug,
        "name": artist.name,
        "bio": artist.bio,
        "photo_url": artist.photo_url,
        "performances": [performance.to_view() for performance in performances]
    }


# --------------------------------------------------
# POST /api/artists
# --------------------------------------------------
@app.post("/api/artists", status_code=201)
def create_artist(artist: ArtistCreate):
    """Ajoute un artiste au festival."""
    name = artist.name.strip()
    if not name:
        raise HTTPException(status_code=422, detail="Artist name cannot be empty.")

    slug = name_to_slug(name)

    # Vérifier que l'artiste n'existe pas déjà.
    if slug in get_artists_by_slug():
        raise HTTPException(status_code=409, detail="Artist already exists.")

    new_artist = {
        "name": name,
        "bio": artist.bio.strip(),
        "photo_url": artist.photo_url.strip()
    }

    festival["artists"].append(new_artist)

    # Enregistrer les données dans festival.json.
    with DATA_FILE.open("w", encoding="utf-8") as file:
        json.dump(festival, file, ensure_ascii=False, indent=2)
        file.write("\n")

    return {"slug": slug, **new_artist}


# --------------------------------------------------
# GET /api/programme
# --------------------------------------------------
@app.get("/api/programme")
def get_programme(day: date | None = None, venue: str | None = None):
    if venue is not None and festival_objects.get_venue(venue) is None:
        raise HTTPException(status_code=404, detail="Unknown venue.")
    performances = festival_objects._performances
    if day is not None:
        performances = [performance for performance in performances if performance.festival_day == day]
    if venue is not None:
        performances = [performance for performance in performances if performance.venue.slug == venue]
    return [ performance.to_view() for performance in sorted(performances, key=lambda performance: performance.start)]


@app.post("/api/performances", status_code=201)
def create_performance(performance: PerformanceCreate):
    """Ajoute une performance au festival."""
    item = performance.model_dump(mode="json")

    # Vérifier que le type de performance est valide.
    if item["kind"] not in ("solo", "lineup", "workshop"):
        raise HTTPException(status_code=422, detail="Invalid performance kind.")

    # Vérifier que la durée est positive.
    if not 1 <= item["duration_minutes"] <= 360:
        raise HTTPException(status_code=422, detail="Duration must be between 1 and 360 minutes.")

    # Vérifier les champs propres à chaque type.
    if item["kind"] == "solo" and not item["artist"]:
        raise HTTPException(status_code=422, detail="A solo performance requires an artist.")

    if item["kind"] == "lineup":
        if not item["host"] or len(item["acts"]) < 2:
            raise HTTPException(status_code=422, detail="A lineup requires a host and at least two acts.")

    if item["kind"] == "workshop":
        if not item["teacher"] or item["max_participants"] is None:
            raise HTTPException(status_code=422, detail="A workshop requires a teacher and a participant limit.")
        if item["max_participants"] <= 0:
            raise HTTPException(status_code=422, detail="The participant limit must be positive.")

    # Les ateliers commencent avec une liste de participants vide.
    if item["kind"] == "workshop":
        item["participants"] = []

    # Vérifier que les données permettent de construire la performance.
    build_performance(item)

    # Vérifier les conflits de planning.
    check_performance_conflicts(item)
    check_festival_dates(item)

    # Enregistrer la performance dans les données du festival.
    festival["performances"].append(item)

    with DATA_FILE.open("w", encoding="utf-8") as file:
        json.dump(festival, file, ensure_ascii=False, indent=2)
        file.write("\n")

    return build_performance(item)


@app.put("/api/performances/{performance_id}")
def update_performance(performance_id: str, performance: PerformanceCreate,):
    """Modifie une performance existante."""
    # Retrouver la performance dans les données du festival.
    existing = None
    for item in festival["performances"]:
        if get_performance_id(item["venue"], datetime.fromisoformat(item["start"]),) == performance_id:
            existing = item
            break
    if existing is None:
        raise HTTPException(status_code=404, detail="Unknown performance.")

    # Convertir les données reçues en format compatible avec le JSON.
    updated = performance.model_dump(mode="json")

    # Vérifier les données principales.
    if updated["kind"] not in ("solo", "lineup", "workshop"):
        raise HTTPException(status_code=422, detail="Invalid performance kind.")

    if updated["duration_minutes"] <= 0:
        raise HTTPException(status_code=422, detail="Duration must be positive.")

    if updated["kind"] == "solo" and not updated["artist"]:
        raise HTTPException(status_code=422, detail="A solo performance requires an artist.")

    if updated["kind"] == "lineup":
        if not updated["host"] or not updated["acts"]:
            raise HTTPException(status_code=422, detail="A lineup requires a host and at least one act.")

    if updated["kind"] == "workshop":
        if (not updated["teacher"] or updated["max_participants"] is None or updated["max_participants"] <= 0):
            raise HTTPException(status_code=422, detail="A workshop requires a teacher and a positive participant limit.")

        # Conserver les inscriptions déjà enregistrées.
        updated["participants"] = existing.get("participants", [])

    # Vérifier que la performance peut être construite.
    build_performance(updated)

    # Vérifier les conflits, sans comparer avec l'ancienne version.
    check_performance_conflicts(updated, exclude=existing)
    check_festival_dates(updated)

    # Remplacer les anciennes données par les nouvelles.
    index = festival["performances"].index(existing)
    festival["performances"][index] = updated

    # Sauvegarder les modifications.
    with DATA_FILE.open("w", encoding="utf-8") as file:
        json.dump(festival, file, ensure_ascii=False, indent=2)
        file.write("\n")

    return build_performance(updated)


@app.delete("/api/performances/{performance_id}", status_code=204)
def delete_performance(performance_id: str):
    """Supprime une performance du festival."""
    # Rechercher la performance à supprimer.
    existing = None
    for item in festival["performances"]:
        start = datetime.fromisoformat(item["start"])
        current_id = get_performance_id(item["venue"], start)
        if current_id == performance_id:
            existing = item
            break

    # Vérifier que la performance existe.
    if existing is None:
        raise HTTPException(status_code=404, detail="Unknown performance.",)

    # Supprimer la performance de la liste.
    festival["performances"].remove(existing)

    # Enregistrer les modifications dans festival.json.
    with DATA_FILE.open("w", encoding="utf-8") as file:
        json.dump(festival, file, ensure_ascii=False, indent=2)
        file.write("\n")

    return None


@app.get("/api/performances/{performance_id}")
def get_performance(performance_id: str):
    performance = festival_objects.get_performance(performance_id)
    if performance is None:
        raise HTTPException(status_code=404, detail="Unknown performance.")
    return performance.to_view()



# --------------------------------------------------
# POST /api/performances/{performance_id}/participants
# --------------------------------------------------
@app.post("/api/performances/{performance_id}/participants", status_code=201)
def register_participant(performance_id: str, participant: ParticipantCreate):
    """Inscrit une personne à un atelier."""
    # Rechercher la performance.
    item = None

    for performance in festival["performances"]:
        start = datetime.fromisoformat(performance["start"])
        current_id = get_performance_id(performance["venue"], start)
        if current_id == performance_id:
            item = performance
            break

    if item is None:
        raise HTTPException(status_code=404, detail="Unknown performance.")

    # Vérifier qu'il s'agit d'un atelier.
    if item["kind"] != "workshop":
        raise HTTPException(status_code=422, detail="This performance is not a workshop.")

    # Vérifier le nom.
    name = participant.name.strip()
    if not name:
        raise HTTPException(status_code=422, detail="Participant name cannot be empty.")

    # Vérifier les places disponibles.
    participants = item.setdefault("participants", [])
    if len(participants) >= item["max_participants"]:
        raise HTTPException(status_code=409, detail="Workshop is full.")

    # Ajouter le participant.
    participants.append(name)

    # Enregistrer immédiatement dans festival.json.
    with DATA_FILE.open("w", encoding="utf-8") as file:
        json.dump(festival, file, ensure_ascii=False, indent=2)
        file.write("\n")

    # Retourner l'atelier actualisé, notamment places_left.
    return build_performance(item)


@app.get("/api/now")
def get_now(at: datetime | None = None):
    moment = at if at is not None else datetime.now()
    performances = get_all_performances()
    now_playing = []
    up_next = []

    for item in performances:
        start = datetime.fromisoformat(item["start"])
        end = datetime.fromisoformat(item["end"])
        if start <= moment < end:
            now_playing.append(item)
        elif start > moment:
            up_next.append(item)

    return {
        "at": moment.isoformat(timespec="minutes"),
        "now_playing": now_playing[:3],
        "up_next": up_next[:3],
    }



# --------------------------------------------------
# Site web statique
# --------------------------------------------------
WEB_DIRECTORY = (Path(__file__).parent.parent / "deauville-starter-main" / "web" / "public")
ADMIN_DIRECTORY = (Path(__file__).parent.parent / "deauville-starter-main" / "web" / "admin")
app.mount("/admin", StaticFiles(directory=ADMIN_DIRECTORY, html=True), name="admin")
app.mount("/", StaticFiles(directory=WEB_DIRECTORY, html=True), name="public",)