"""Command-line entry point for the Deauville festival project."""

from __future__ import annotations

import argparse
from datetime import date, datetime, timedelta
from pathlib import Path

from . import api
from .storage import JsonStorage, Storage

DEFAULT_DATA = Path(__file__).resolve().parent / "data" / "festival.json"


def print_programme(storage: Storage, day_text: str) -> None:
    """Print the programme for a festival day (the step 04 CLI behaviour)."""
    day = date.fromisoformat(day_text)
    data = storage.load()
    events = []
    for item in data["performances"]:
        start = datetime.fromisoformat(item["start"])
        festival_day = start.date() - timedelta(days=1) if start.hour < 6 else start.date()
        if festival_day == day:
            events.append((start, item))
    events.sort(key=lambda pair: pair[0])
    if events:
        print(f"Programme for {day.strftime('%A %d %B')} :")
    else:
        print(f"No event for {day.strftime('%A %d %B')}.")
    for start, item in events:
        end = start + timedelta(minutes=item["duration_minutes"])
        venue = item["venue"].replace("-", " ").title()
        print(f"{start:%H:%M}-{end:%H:%M} | {venue} | {item['title']} ({item['kind']})")



def main() -> None:
    parser = argparse.ArgumentParser(prog="deauville", description="Programme du Festival du Rire de Deauville")
    parser.add_argument("--data", type=Path, default=DEFAULT_DATA, help="chemin vers le fichier JSON du festival")
    subparsers = parser.add_subparsers(dest="command", required=True)
    programme = subparsers.add_parser("programme", help="afficher le programme d'une journée")
    programme.add_argument("day", help="date au format YYYY-MM-DD")
    programme.add_argument("--data", type=Path, default=argparse.SUPPRESS, help="chemin vers le fichier JSON du festival")
    serve = subparsers.add_parser("serve", help="lancer le site et l'API d'administration")
    serve.add_argument("--data", type=Path, default=argparse.SUPPRESS, help="chemin vers le fichier JSON du festival")
    args = parser.parse_args()

    storage = JsonStorage(args.data)
    if args.command == "programme":
        print_programme(storage, args.day)
        return

    import uvicorn

    application = api.create_app(storage)
    uvicorn.run(application, host="127.0.0.1", port=8000)


if __name__ == "__main__":
    main()
