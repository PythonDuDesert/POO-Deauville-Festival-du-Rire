import unicodedata
from datetime import date, datetime, time, timedelta
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .festival import (
    Artist,
    FestivalConflict,
    FestivalError,
    FestivalInvalid,
    FestivalNotFound,
    Lineup,
    SoloShow,
    Workshop,
    create_performance_id,
    load_festival,
)
from .storage import JsonStorage, Storage

PACKAGE_DIRECTORY = Path(__file__).resolve().parent
DATA_FILE = PACKAGE_DIRECTORY / "data" / "festival.json"
WEB_DIRECTORY = PACKAGE_DIRECTORY / "web" / "public"
ADMIN_DIRECTORY = PACKAGE_DIRECTORY / "web" / "admin"

# The persistence backend is replaceable; routes only use this interface.
storage: Storage = JsonStorage(DATA_FILE)
festival = storage.load()
festival_objects = load_festival(festival)


def configure_storage(new_storage: Storage) -> None:
    """Inject a persistence backend and initialise the application state."""
    global storage, festival, festival_objects
    storage = new_storage
    festival = storage.load()
    festival_objects = load_festival(festival)


def save_festival():
    """Persist the current data through the configured storage interface."""
    global festival_objects
    storage.save(festival)
    festival_objects = load_festival(festival)


def build_performance_object(item):
    """Construit un objet métier depuis les données d'une performance."""
    venue = festival_objects.get_venue(item["venue"])
    if venue is None:
        raise FestivalNotFound("Unknown venue.")

    kind = item["kind"]
    classes = {
        "solo": SoloShow,
        "lineup": Lineup,
        "workshop": Workshop,
    }

    cls = classes.get(kind)
    if cls is None:
        raise FestivalInvalid("Invalid performance kind.")

    start = datetime.fromisoformat(item["start"])
    common = {
        "id": create_performance_id(venue, start.isoformat()),
        "title": item["title"],
        "venue": venue,
        "start": start,
        "duration_minutes": item["duration_minutes"],
        "description": item.get("description", ""),
    }

    try:
        if cls is SoloShow:
            artist = festival_objects.get_artist(item.get("artist"))
            if artist is None:
                raise FestivalNotFound("Unknown artist.")
            return SoloShow(**common, artist=artist, min_age=item.get("min_age", 0) or 0)

        if cls is Lineup:
            host = festival_objects.get_artist(item.get("host"))
            acts = [festival_objects.get_artist(slug) for slug in item.get("acts", [])]
            if host is None or any(act is None for act in acts):
                raise FestivalNotFound("Unknown artist.")
            return Lineup(**common, host=host, acts=acts)

        teacher = festival_objects.get_artist(item.get("teacher"))
        if teacher is None:
            raise FestivalNotFound("Unknown artist.")

        return Workshop(
            **common,
            teacher=teacher,
            max_participants=item.get("max_participants"),
            participants=item.get("participants", []),
        )

    except TypeError as exc:
        raise FestivalInvalid(str(exc)) from exc


class ArtistCreate(BaseModel):
    name: str
    bio: str = ""
    photo_url: str = ""

class PerformanceCreate(BaseModel):
    kind: str
    title: str
    venue: str
    start: datetime
    duration_minutes: int
    description: str = ""

    # Champs spécifiques selon le type
    artist: str | None = None
    min_age: int | None = None
    host: str | None = None
    acts: list[str] = Field(default_factory=list)
    teacher: str | None = None
    max_participants: int | None = None

class ParticipantCreate(BaseModel):
    name: str


def name_to_slug(name: str) -> str:
    name = unicodedata.normalize("NFKD", name)
    name = "".join(char for char in name if not unicodedata.combining(char))
    return name.casefold().replace(" ", "-")

def get_venues_by_slug():
    return {
        name_to_slug(venue["name"]): venue
        for venue in festival["venues"]
    }

def get_artists_by_slug():
    return {
        name_to_slug(artist["name"]): artist
        for artist in festival["artists"]
    }

def get_festival_day(start):
    # Les événements avant 06 h appartiennent à la soirée précédente.
    day = start.date()
    if start.time() < time(6, 0):
        day -= timedelta(days=1)
    return day.isoformat()

def get_performance_id(venue_slug, start):
    return f"{venue_slug}-{start:%Y-%m-%d-%H%M}"

def build_performance(item):
    venues = get_venues_by_slug()
    artists_by_slug = get_artists_by_slug()
    venue_slug = item["venue"]
    venue = venues.get(venue_slug)

    if venue is None:
        raise FestivalNotFound("Unknown venue.")

    start = datetime.fromisoformat(item["start"])
    end = start + timedelta(minutes=item["duration_minutes"])
    kind = item["kind"]
    if kind == "solo":
        artist_slugs = [item["artist"]]
    elif kind == "lineup":
        artist_slugs = [item["host"], *item["acts"]]
    elif kind == "workshop":
        artist_slugs = [item["teacher"]]
    else:
        raise FestivalInvalid("Invalid performance kind.")

    # Vérifier que tous les artistes existent avant de les utiliser.
    for slug in artist_slugs:
        if slug not in artists_by_slug:
            raise FestivalNotFound(f"Unknown artist: {slug}.")

    # Construire le résumé après les vérifications.
    if kind == "solo":
        summary = f"with {artists_by_slug[item['artist']]['name']}"
    elif kind == "lineup":
        host = artists_by_slug[item["host"]]["name"]
        acts = ", ".join(artists_by_slug[slug]["name"] for slug in item["acts"])
        summary = f"hosted by {host}, with {acts}"
    else:  # workshop
        teacher = artists_by_slug[item["teacher"]]["name"]
        summary = f"with {teacher}"

    # Vérifier que tous les artistes existent.
    for slug in artist_slugs:
        if slug not in artists_by_slug:
            raise FestivalNotFound(f"Unknown artist: {slug}.")

    artists = [
        {"slug": slug, "name": artists_by_slug[slug]["name"]}
        for slug in artist_slugs
    ]

    result = {
        "id": get_performance_id(venue_slug, start),
        "kind": kind,
        "title": item["title"],
        "venue": venue_slug,
        "venue_name": venue["name"],
        "start": start.isoformat(timespec="minutes"),
        "end": end.isoformat(timespec="minutes"),
        "duration_minutes": item["duration_minutes"],
        "festival_day": get_festival_day(start),
        "description": item.get("description", ""),
        "summary": summary,
        "capacity": (item["max_participants"] if kind == "workshop" else venue["capacity"]),
        "artists": artists,
    }

    # Ajouter les champs spécifiques au type.
    for field in ("artist", "min_age", "host", "acts", "teacher", "max_participants", "participants"):
        if field in item:
            result[field] = item[field]

    if kind == "workshop":
        result["places_left"] = max(0, item["max_participants"] - len(item.get("participants", [])),)

    return result

def get_all_performances():
    performances = [build_performance(item) for item in festival["performances"]]
    return sorted(performances, key=lambda item: item["start"])

def check_performance_conflicts(candidate, exclude=None):
    """Vérifie les chevauchements et les 15 minutes de battement."""
    candidate_start = datetime.fromisoformat(candidate["start"])
    candidate_end = candidate_start + timedelta(minutes=candidate["duration_minutes"])
    candidate_artists = set()

    if candidate["kind"] == "solo":
        candidate_artists.add(candidate["artist"])
    elif candidate["kind"] == "lineup":
        candidate_artists.add(candidate["host"])
        candidate_artists.update(candidate["acts"])
    elif candidate["kind"] == "workshop":
        candidate_artists.add(candidate["teacher"])

    minimum_gap = timedelta(minutes=15)
    for existing in festival["performances"]:
        if existing is exclude:
            continue

        existing_start = datetime.fromisoformat(existing["start"])
        existing_end = existing_start + timedelta(minutes=existing["duration_minutes"])
        same_venue = candidate["venue"] == existing["venue"]
        existing_artists = set()
        if existing["kind"] == "solo":
            existing_artists.add(existing["artist"])
        elif existing["kind"] == "lineup":
            existing_artists.add(existing["host"])
            existing_artists.update(existing["acts"])
        elif existing["kind"] == "workshop":
            existing_artists.add(existing["teacher"])

        shared_artists = candidate_artists & existing_artists
        if not same_venue and not shared_artists:
            continue

        overlaps = candidate_start < existing_end and existing_start < candidate_end
        if overlaps:
            if same_venue:
                raise FestivalConflict("Venue is already occupied.")
            raise FestivalConflict("An artist is already busy.")

        if candidate_end <= existing_start:
            gap = existing_start - candidate_end
        else:
            gap = candidate_start - existing_end
        if gap < minimum_gap:
            if same_venue:
                raise FestivalConflict(
                    "At least 15 minutes are required between performances in the same venue."
                )
            raise FestivalConflict(
                "At least 15 minutes are required between performances involving the same artist."
            )


def check_festival_dates(item):
    """Vérifie que la performance appartient aux dates du festival."""
    start = datetime.fromisoformat(item["start"])
    festival_day = date.fromisoformat(get_festival_day(start))
    first_day = date.fromisoformat(festival["first_day"])
    last_day = date.fromisoformat(festival["last_day"])
    if not first_day <= festival_day <= last_day:
        raise FestivalConflict("Performance date is outside the festival.")


# --------------------------------------------------
# Application FastAPI
# --------------------------------------------------
app = FastAPI(title="Festival API", description="API du festival : informations, artistes et lieux.", version="1.0.0")


@app.exception_handler(FestivalError)
async def festival_error_handler(request: Request, exc: FestivalError):
    """Convertit centralement les erreurs métier en réponses HTTP."""
    return JSONResponse(status_code=exc.status_code, content={"detail": str(exc)})


# --------------------------------------------------
# GET /api/festival
# --------------------------------------------------
@app.get("/api/festival")
def get_festival():
    """Retourne les informations générales du festival et ses dates."""
    first_day = date.fromisoformat(festival["first_day"])
    last_day = date.fromisoformat(festival["last_day"])
    days = []
    current_day = first_day
    while current_day <= last_day:
        days.append(current_day.isoformat())
        current_day += timedelta(days=1)

    return {
        "name": festival["name"],
        "first_day": festival["first_day"],
        "last_day": festival["last_day"],
        "days": days,
    }


# --------------------------------------------------
# GET /api/venues
# --------------------------------------------------
@app.get("/api/venues")
def get_venues():
    """Retourne les lieux dans leur ordre d'origine."""
    return [
        {
            "slug": name_to_slug(venue["name"]),
            "name": venue["name"],
            "capacity": venue["capacity"],
            "address": venue["address"],
        }
        for venue in festival["venues"]
    ]


# --------------------------------------------------
# GET /api/artists
# --------------------------------------------------
@app.get("/api/artists")
def get_artists():
    """Retourne la liste des artistes du festival."""
    artists = sorted(festival_objects.artists, key=lambda artist: artist.name.casefold())
    return [
        {
            "slug": artist.slug,
            "name": artist.name,
            "bio": artist.bio,
            "photo_url": artist.photo_url,
        }
        for artist in artists
    ]


# --------------------------------------------------
# GET /api/artists
# --------------------------------------------------
@app.get("/api/artists/{slug}")
def get_artist(slug: str):
    artist = festival_objects.get_artist(slug)
    if artist is None:
        raise FestivalNotFound("Unknown artist.")
    performances = festival_objects.performances_artiste(slug)
    return {
        "slug": artist.slug,
        "name": artist.name,
        "bio": artist.bio,
        "photo_url": artist.photo_url,
        "performances": [performance.to_view() for performance in performances]
    }


# --------------------------------------------------
# POST /api/artists
# --------------------------------------------------
@app.post("/api/artists", status_code=201)
def create_artist(artist: ArtistCreate):
    """Ajoute un artiste au festival."""
    global festival_objects
    name = artist.name.strip()
    if not name:
        raise FestivalInvalid("Artist name cannot be empty.")

    slug = name_to_slug(name)

    new_artist = {
        "name": name,
        "bio": artist.bio.strip(),
        "photo_url": artist.photo_url.strip()
    }
    # Les règles d'unicité sont appliquées par le modèle métier.
    festival_objects.add_artist(Artist(name=name, slug=slug, bio=new_artist["bio"], photo_url=new_artist["photo_url"]))
    festival["artists"].append(new_artist)
    try:
        save_festival()
    except Exception:
        festival["artists"].pop()
        festival_objects = load_festival(festival)
        raise

    return {"slug": slug, **new_artist}


# --------------------------------------------------
# GET /api/programme
# --------------------------------------------------
@app.get("/api/programme")
def get_programme(day: date | None = None, venue: str | None = None):
    if venue is not None and festival_objects.get_venue(venue) is None:
        raise FestivalNotFound("Unknown venue.")
    performances = festival_objects.performances
    if day is not None:
        performances = [performance for performance in performances if performance.festival_day == day]
    if venue is not None:
        performances = [performance for performance in performances if performance.venue.slug == venue]
    return [ performance.to_view() for performance in sorted(performances, key=lambda performance: performance.start)]



@app.post("/api/performances", status_code=201)
def create_performance(performance: PerformanceCreate):
    """Ajoute une performance au festival."""
    item = performance.model_dump(mode="json")
    if item["kind"] not in ("solo", "lineup", "workshop"):
        raise FestivalInvalid("Invalid performance kind.")
    if item["kind"] == "workshop":
        item["participants"] = []

    # Construire l'objet métier.
    candidate = build_performance_object(item)

    # Vérifier les règles métier avant de modifier le modèle.
    festival_objects.validate_performance(candidate)

    # Préparer la sauvegarde JSON.
    festival["performances"].append(item)
    try:
        save_festival()
    except Exception:
        festival["performances"].remove(item)
        raise

    return build_performance(item)


@app.put("/api/performances/{performance_id}")
def update_performance(performance_id: str, performance: PerformanceCreate):
    """Modifie une performance existante."""
    global festival_objects
    # Retrouver la performance dans le JSON.
    existing_item = next(
        (item for item in festival["performances"] if get_performance_id(item["venue"], datetime.fromisoformat(item["start"])) == performance_id),
        None
    )

    if existing_item is None:
        raise FestivalNotFound("Unknown performance.")

    updated = performance.model_dump(mode="json")
    if updated["kind"] not in ("solo", "lineup", "workshop"):
        raise FestivalInvalid("Invalid performance kind.")

    # Conserver les inscriptions si la performance reste un atelier.
    if updated["kind"] == "workshop":
        updated["participants"] = existing_item.get("participants", [])

    # Construire le nouvel objet métier.
    candidate = build_performance_object(updated)

    # Récupérer l'ancienne performance dans le modèle objet.
    existing_object = festival_objects.get_performance(performance_id)
    if existing_object is None:
        raise FestivalNotFound("Unknown performance.")

    # Sauvegarder l'ancien état pour pouvoir revenir en arrière.
    index = festival["performances"].index(existing_item)

    festival_objects.update_performance(performance_id, candidate)

    festival["performances"][index] = updated
    try:
        save_festival()
    except Exception:
        # Restaurer le JSON et le modèle objet si la sauvegarde échoue.
        festival["performances"][index] = existing_item
        festival_objects = load_festival(festival)
        raise

    return build_performance(updated)


@app.delete("/api/performances/{performance_id}", status_code=204)
def delete_performance(performance_id: str):
    """Supprime une performance du festival."""
    global festival_objects

    # Vérifier que la performance existe dans le modèle métier.
    existing_object = festival_objects.get_performance(performance_id)
    if existing_object is None:
        raise FestivalNotFound("Unknown performance.")

    # Retrouver les données correspondantes dans le JSON.
    existing_item = next(
            (item for item in festival["performances"] if get_performance_id(item["venue"], datetime.fromisoformat(item["start"])) == performance_id), None
        )
    if existing_item is None:
        raise FestivalNotFound("Unknown performance.")

    index = festival["performances"].index(existing_item)

    # Supprimer via le modèle métier.
    festival_objects.cancel_performance(performance_id)
    festival["performances"].pop(index)

    try:
        save_festival()
    except Exception:
        # Restaurer le JSON et le modèle objet en cas d'échec.
        festival["performances"].insert(index, existing_item)
        festival_objects = load_festival(festival)
        raise

    return None


@app.get("/api/performances/{performance_id}")
def get_performance(performance_id: str):
    performance = festival_objects.get_performance(performance_id)
    if performance is None:
        raise FestivalNotFound("Unknown performance.")
    return performance.to_view()



# --------------------------------------------------
# POST /api/performances/{performance_id}/participants
# --------------------------------------------------
@app.post("/api/performances/{performance_id}/participants", status_code=201)
def register_participant(performance_id: str, participant: ParticipantCreate,):
    """Inscrit une personne à un atelier."""
    global festival_objects
    # Retrouver l'atelier dans le modèle métier.
    performance = festival_objects.get_performance(performance_id)
    if performance is None:
        raise FestivalNotFound("Unknown performance.")
    if not isinstance(performance, Workshop):
        raise FestivalInvalid("This performance is not a workshop.")

    # Retrouver les données à sauvegarder dans le JSON.
    item = next(
                (item for item in festival["performances"]
                    if get_performance_id( item["venue"], datetime.fromisoformat(item["start"])) == performance_id), None
            )
    if item is None:
        raise FestivalNotFound("Unknown performance.")

    name = participant.name.strip()

    # L'inscription et la vérification des places sont gérées par la classe Workshop.
    performance.register_participant(name)

    item.setdefault("participants", []).append(name)

    try:
        save_festival()
    except Exception:
        # Annuler l'inscription si la sauvegarde échoue.
        item["participants"].pop()
        festival_objects = load_festival(festival)
        raise

    return build_performance(item)


@app.get("/api/now")
def get_now(at: datetime | None = None):
    """Retourne les performances en cours et les prochaines."""
    moment = at if at is not None else datetime.now()
    now_playing = festival_objects.now_playing(moment)
    up_next = festival_objects.up_next(moment, limit=3)
    return {
        "at": moment.isoformat(timespec="minutes"),
        "now_playing": [performance.to_view() for performance in now_playing[:3]],
        "up_next": [performance.to_view() for performance in up_next]
    }



# --------------------------------------------------
# Site web statique
# --------------------------------------------------
def create_app(data_storage: Storage | None = None) -> FastAPI:
    """Configure and return the ASGI application with an injected storage."""
    if data_storage is not None:
        configure_storage(data_storage)
    return app

# Default application used by `uvicorn deauville.api:app` and the tests.
app.mount("/admin", StaticFiles(directory=ADMIN_DIRECTORY, html=True), name="admin")
app.mount("/", StaticFiles(directory=WEB_DIRECTORY, html=True), name="public")