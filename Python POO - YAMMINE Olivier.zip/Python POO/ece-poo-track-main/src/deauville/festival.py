import unicodedata
from abc import ABC, abstractmethod
from datetime import date, datetime, timedelta

DAY_CHANGE = 6


class FestivalError(ValueError):
    """Base class for expected festival/business-rule errors."""

    status_code = 422


class FestivalNotFound(FestivalError):
    status_code = 404


class FestivalConflict(FestivalError):
    status_code = 409


class FestivalInvalid(FestivalError):
    status_code = 422


# Bloc 3
class Venue:
    def __init__(self, name, slug, capacity, address):
        self.name = name
        self.slug = slug
        self.capacity = capacity
        self.address = address


class Artist:
    def __init__(self, name, slug, bio, photo_url):
        self.name = name
        self.slug = slug
        self.bio = bio
        self.photo_url = photo_url


class Performance(ABC):
    def __init__(self, id, title, venue, start, duration_minutes, description):
        self.id = id
        self.title = title
        self.venue = venue
        self.start = datetime.fromisoformat(start) if isinstance(start, str) else start
        self.duration_minutes = duration_minutes
        self.description = description

    @property
    def end(self):
        return self.start + timedelta(minutes=self.duration_minutes)

    @property
    def festival_day(self):
        return (
            self.start.date()
            if self.start.hour >= DAY_CHANGE
            else self.start.date() - timedelta(days=1)
        )

    @abstractmethod
    def involves(self, artist):
        pass

    @abstractmethod
    def to_view(self):
        pass

    def common_view(self, artists, summary, capacity):
        return {
            "id": self.id,
            "kind": self.kind,
            "title": self.title,
            "venue": self.venue.slug,
            "venue_name": self.venue.name,
            "festival_day": self.festival_day.isoformat(),
            "start": self.start.isoformat(timespec="minutes"),
            "end": self.end.isoformat(timespec="minutes"),
            "duration_minutes": self.duration_minutes,
            "description": self.description,
            "summary": summary,
            "capacity": capacity,
            "artists": [
                {"slug": artist.slug, "name": artist.name} for artist in artists
            ],
        }


class SoloShow(Performance):
    kind = "solo"

    def __init__(self, *args, artist, min_age=0, **kwargs):
        super().__init__(*args, **kwargs)
        self.artist = artist
        self.min_age = min_age

    def involves(self, artist):
        return self.artist.slug == artist.slug

    def to_view(self):
        result = self.common_view(
            [self.artist], f"with {self.artist.name}", self.venue.capacity
        )
        result.update({"artist": self.artist.slug, "min_age": self.min_age})
        return result


class Lineup(Performance):
    kind = "lineup"

    def __init__(self, *args, host, acts, **kwargs):
        super().__init__(*args, **kwargs)
        self.host = host
        self._acts = list(acts)

    @property
    def acts(self):
        return list(self._acts)

    def involves(self, artist):
        return self.host.slug == artist.slug or any(
            act.slug == artist.slug for act in self.acts
        )

    def to_view(self):
        names = ", ".join(act.name for act in self.acts)
        result = self.common_view(
            [self.host, *self.acts],
            f"hosted by {self.host.name}, with {names}",
            self.venue.capacity,
        )
        result.update({"host": self.host.slug, "acts": [act.slug for act in self.acts]})
        return result


class Workshop(Performance):
    kind = "workshop"

    def __init__(self, *args, teacher, max_participants, participants=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.teacher = teacher
        self.max_participants = max_participants
        self._participants = list(participants) if participants is not None else []

    @property
    def participants(self):
        return list(self._participants)

    def involves(self, artist):
        return self.teacher.slug == artist.slug

    def register_participant(self, name):
        """Inscrit un participant si une place est disponible."""
        name = name.strip()
        if not name:
            raise FestivalInvalid("Participant name cannot be empty.")
        capacity = min(self.max_participants, self.venue.capacity)
        if len(self.participants) >= capacity:
            raise FestivalConflict("Workshop is full.")
        if any(
            existing.casefold() == name.casefold() for existing in self._participants
        ):
            raise FestivalConflict("Participant is already registered.")
        self._participants.append(name)

    def to_view(self):
        result = self.common_view(
            [self.teacher],
            f"with {self.teacher.name}",
            min(self.max_participants, self.venue.capacity),
        )
        result.update(
            {
                "teacher": self.teacher.slug,
                "max_participants": self.max_participants,
                "participants": self.participants,
                "places_left": max(
                    0,
                    min(self.max_participants, self.venue.capacity)
                    - len(self.participants),
                ),
            }
        )
        return result


class Festival:
    def __init__(
        self, name, first_day, last_day, venues=None, artists=None, performances=None
    ):
        self.name = name
        self.first_day = (
            date.fromisoformat(first_day) if isinstance(first_day, str) else first_day
        )
        self.last_day = (
            date.fromisoformat(last_day) if isinstance(last_day, str) else last_day
        )
        self._venues = list(venues) if venues is not None else []
        self._artists = list(artists) if artists is not None else []
        self._performances = list(performances) if performances is not None else []

    @property
    def venues(self):
        return list(self._venues)

    @property
    def artists(self):
        return list(self._artists)

    @property
    def performances(self):
        return list(self._performances)

    def add_artist(self, artist):
        if not artist.name.strip():
            raise FestivalInvalid("Artist name cannot be empty.")
        if any(existing.slug == artist.slug for existing in self._artists):
            raise FestivalConflict("Artist already exists.")
        self._artists.append(artist)

    def get_venue(self, slug):
        return next((venue for venue in self._venues if venue.slug == slug), None)

    def get_artist(self, slug):
        return next((artist for artist in self._artists if artist.slug == slug), None)

    def get_performance(self, performance_id):
        return next(
            (
                performance
                for performance in self._performances
                if performance.id == performance_id
            ),
            None,
        )

    def program_for_day(self, day, venue_slug=None):
        if isinstance(day, str):
            day = datetime.fromisoformat(day).date()
        performances = [
            performance
            for performance in self._performances
            if performance.festival_day == day
        ]
        if venue_slug is not None:
            performances = [
                performance
                for performance in performances
                if performance.venue.slug == venue_slug
            ]
        return sorted(performances, key=lambda performance: performance.start)

    def performances_artiste(self, artist_slug):
        artist = self.get_artist(artist_slug)
        if artist is None:
            return []
        performances = [
            performance
            for performance in self._performances
            if performance.involves(artist)
        ]
        return sorted(performances, key=lambda performance: performance.start)

    def now_playing(self, at=None):
        if at is None:
            at = datetime.now()
        elif isinstance(at, str):
            at = datetime.fromisoformat(at)
        return sorted(
            [
                performance
                for performance in self._performances
                if performance.start <= at < performance.end
            ],
            key=lambda performance: performance.start,
        )

    def up_next(self, at=None, limit=3):
        if at is None:
            at = datetime.now()
        elif isinstance(at, str):
            at = datetime.fromisoformat(at)
        performances = [
            performance for performance in self._performances if performance.start > at
        ]
        performances.sort(key=lambda performance: performance.start)
        return performances[:limit]

    def has_time_conflict(self, first, second):
        return first.start < second.end and second.start < first.end

    def artists_in(self, performance):
        if isinstance(performance, SoloShow):
            return {performance.artist.slug}
        if isinstance(performance, Lineup):
            return {
                performance.host.slug,
                *(artist.slug for artist in performance.acts),
            }
        if isinstance(performance, Workshop):
            return {performance.teacher.slug}
        return set()

    def check_performance_conflicts(self, candidate, exclude=None):
        """Reject overlaps and require 15 minutes between shared resources."""
        candidate_artists = self.artists_in(candidate)
        minimum_gap = timedelta(minutes=15)

        for existing in self._performances:
            if existing is exclude:
                continue

            same_venue = candidate.venue.slug == existing.venue.slug
            shared_artists = candidate_artists & self.artists_in(existing)
            if not same_venue and not shared_artists:
                continue

            # Preserve the existing, more specific errors for actual overlaps.
            if self.has_time_conflict(candidate, existing):
                if same_venue:
                    raise FestivalConflict("Venue is already occupied.")
                raise FestivalConflict("An artist is already busy.")

            # A resource must remain free for 15 full minutes between shows.
            if candidate.end <= existing.start:
                gap = existing.start - candidate.end
            else:
                gap = candidate.start - existing.end

            if gap < minimum_gap:
                if same_venue:
                    raise FestivalConflict(
                        "At least 15 minutes are required between performances "
                        "in the same venue."
                    )
                raise FestivalConflict(
                    "At least 15 minutes are required between performances "
                    "involving the same artist."
                )

    def validate_duration(self, performance):
        duration = (performance.end - performance.start).total_seconds() / 60
        if duration < 1 or duration > 360:
            raise FestivalInvalid("Duration must be between 1 and 360 minutes.")

    def validate_festival_dates(self, performance):
        day = performance.festival_day
        if day < self.first_day or day > self.last_day:
            raise FestivalConflict("Performance date is outside the festival dates.")

    def validate_performance(self, performance, exclude=None):
        self.validate_performance_type(performance)
        self.validate_duration(performance)
        self.validate_festival_dates(performance)
        self.check_performance_conflicts(performance, exclude)

    def validate_performance_type(self, performance):
        if not isinstance(performance, Performance):
            raise FestivalInvalid("Invalid performance object.")
        if isinstance(performance, SoloShow):
            if not 0 <= performance.min_age <= 18:
                raise FestivalInvalid("Minimum age must be between 0 and 18.")

        elif isinstance(performance, Lineup):
            if len(performance.acts) < 2:
                raise FestivalInvalid("A lineup requires at least two acts.")
            if len({artist.slug for artist in performance.acts}) != len(
                performance.acts
            ):
                raise FestivalInvalid("Lineup acts must be unique.")
            if performance.host.slug in {artist.slug for artist in performance.acts}:
                raise FestivalInvalid("The host cannot also be an act.")
            minimum = 10 * len(performance.acts) + 3 * (len(performance.acts) - 1)
            if performance.duration_minutes < minimum:
                raise FestivalInvalid("Lineup duration is too short.")

        elif isinstance(performance, Workshop):
            if performance.max_participants <= 0:
                raise FestivalInvalid("Participant limit must be positive.")

    def add_performance(self, performance):
        self.validate_performance(performance)
        self._performances.append(performance)

    def update_performance(self, performance_id, updated_performance):
        existing = self.get_performance(performance_id)
        if existing is None:
            raise FestivalNotFound("Performance not found.")
        self.validate_performance(updated_performance, exclude=existing)
        index = self._performances.index(existing)
        self._performances[index] = updated_performance

    def cancel_performance(self, performance_id):
        performance = self.get_performance(performance_id)
        if performance is None:
            raise FestivalNotFound("Performance not found.")
        self._performances.remove(performance)


def create_performance_id(venue, start):
    start_datetime = datetime.fromisoformat(start)
    date = start_datetime.strftime("%Y-%m-%d")
    time = start_datetime.strftime("%H%M")
    return f"{venue.slug}-{date}-{time}"


def load_festival(data):
    """Build the domain model from already-loaded festival data."""
    festival = data

    venues = [
        Venue(
            name=venue["name"],
            slug=name_to_slug(venue["name"]),
            capacity=venue["capacity"],
            address=venue["address"],
        )
        for venue in festival["venues"]
    ]

    artists = [
        Artist(
            name=artist["name"],
            slug=name_to_slug(artist["name"]),
            bio=artist["bio"],
            photo_url=artist["photo_url"],
        )
        for artist in festival["artists"]
    ]

    venues_by_slug = {venue.slug: venue for venue in venues}
    artists_by_slug = {artist.slug: artist for artist in artists}
    performances = []
    kinds = {
        "solo": SoloShow,
        "lineup": Lineup,
        "workshop": Workshop,
    }

    for perf in festival["performances"]:
        venue = venues_by_slug[perf["venue"]]
        cls = kinds.get(perf["kind"])
        if cls is None:
            raise ValueError(f"Unknown performance kind: {perf['kind']}")

        common = {
            "id": create_performance_id(venue, perf["start"]),
            "title": perf["title"],
            "venue": venue,
            "start": perf["start"],
            "duration_minutes": perf["duration_minutes"],
            "description": perf["description"],
        }

        if cls is SoloShow:
            performance = cls(
                **common,
                artist=artists_by_slug[perf["artist"]],
                min_age=perf.get("min_age", 0),
            )
        elif cls is Lineup:
            performance = cls(
                **common,
                host=artists_by_slug[perf["host"]],
                acts=[artists_by_slug[slug] for slug in perf["acts"]],
            )
        else:
            performance = cls(
                **common,
                teacher=artists_by_slug[perf["teacher"]],
                max_participants=perf["max_participants"],
                participants=perf.get("participants", []),
            )
        performances.append(performance)

    return Festival(
        name=festival["name"],
        first_day=festival["first_day"],
        last_day=festival["last_day"],
        venues=venues,
        artists=artists,
        performances=performances,
    )


def name_to_slug(name):
    decomposed = unicodedata.normalize("NFKD", name)
    slug_name = decomposed.encode("ascii", "ignore").decode("ascii")
    result = ""
    for char in slug_name.lower():
        if char.isalnum():
            result += char
        elif not result.endswith("-"):
            result += "-"
    return result


def slug_to_name(name):
    return name.replace("-", " ").strip().title()
