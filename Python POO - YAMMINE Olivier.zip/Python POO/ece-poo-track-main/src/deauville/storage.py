"""Replaceable persistence backends for the festival data."""

from __future__ import annotations

import copy
import json
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

FestivalData = dict[str, Any]


class Storage(ABC):
    """Interface used by the application to load and save festival data."""

    @abstractmethod
    def load(self) -> FestivalData:
        """Return a fresh festival-data dictionary."""

    @abstractmethod
    def save(self, data: FestivalData) -> None:
        """Persist festival data."""


class JsonStorage(Storage):
    """Store festival data in a JSON file."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)

    def load(self) -> FestivalData:
        with self.path.open(encoding="utf-8") as file:
            return json.load(file)

    def save(self, data: FestivalData) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_text(
            json.dumps(data, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        temporary.replace(self.path)


class MemoryStorage(Storage):
    """In-memory storage useful for tests and isolated runs."""

    def __init__(self, initial_data: FestivalData) -> None:
        self._data = copy.deepcopy(initial_data)

    def load(self) -> FestivalData:
        return copy.deepcopy(self._data)

    def save(self, data: FestivalData) -> None:
        self._data = copy.deepcopy(data)
