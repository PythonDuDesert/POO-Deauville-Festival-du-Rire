"""Step 11 checks: interchangeable storage and the installed CLI behaviour."""

import copy
import json
from pathlib import Path

from cli import main, print_programme
from storage import JsonStorage, MemoryStorage

PROJECT = Path(__file__).resolve().parents[1]


def test_memory_storage_copies_data_on_load_and_save():
    original = {"performances": [{"title": "Original"}]}
    storage = MemoryStorage(original)
    loaded = storage.load()
    loaded["performances"][0]["title"] = "Mutated"
    assert storage.load()["performances"][0]["title"] == "Original"
    storage.save(loaded)
    loaded["performances"][0]["title"] = "Mutated again"
    assert storage.load()["performances"][0]["title"] == "Mutated"


def test_json_storage_round_trip(tmp_path):
    path = tmp_path / "nested" / "festival.json"
    expected = {"name": "Festival", "performances": []}
    storage = JsonStorage(path)
    storage.save(expected)
    assert json.loads(path.read_text(encoding="utf-8")) == expected
    assert storage.load() == expected


def test_programme_uses_the_injected_storage(capsys):
    source = json.loads((PROJECT / "data/festival.json").read_text(encoding="utf-8"))
    storage = MemoryStorage(copy.deepcopy(source))
    print_programme(storage, "2027-06-11")
    output = capsys.readouterr().out
    assert "Programme for Friday 11 June" in output
    assert "Improv for Beginners" in output


def test_cli_uses_alternate_data_file(tmp_path, monkeypatch, capsys):
    source = json.loads((PROJECT / "data/festival.json").read_text(encoding="utf-8"))
    source["performances"] = []
    path = tmp_path / "custom.json"
    path.write_text(json.dumps(source), encoding="utf-8")
    assert JsonStorage(path).load()["performances"] == []
    monkeypatch.setattr(
        "sys.argv", ["deauville", "programme", "2027-06-11", "--data", str(path)]
    )
    main()
    assert "No event for Friday 11 June." in capsys.readouterr().out
