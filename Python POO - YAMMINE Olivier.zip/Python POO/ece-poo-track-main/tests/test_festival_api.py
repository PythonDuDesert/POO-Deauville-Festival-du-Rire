"""HTTP-level contract tests; each test owns an isolated in-memory festival."""
from __future__ import annotations

import copy
import json
from datetime import datetime
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from api import create_app, get_performance_id
from storage import MemoryStorage, Storage

ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = ROOT / "data" / "festival.json"


class FailingSaveStorage(MemoryStorage):
    def save(self, data):
        raise OSError("disk is read-only")


class FailingLoadStorage(Storage):
    def load(self):
        raise OSError("file unavailable")

    def save(self, data):
        raise OSError("file unavailable")


@pytest.fixture

def source_data():
    return json.loads(DATA_FILE.read_text(encoding="utf-8"))


@pytest.fixture

def api_client(source_data):
    storage = MemoryStorage(copy.deepcopy(source_data))
    app = create_app(storage)
    with TestClient(app) as client:
        yield client, storage, copy.deepcopy(source_data)


def solo_body(*, venue="le-kiosque", start="2027-06-13T10:00", title="API test solo", artist="nora-lebrun", duration=30):
    return {"kind": "solo", "title": title, "venue": venue, "start": start,
            "duration_minutes": duration, "artist": artist, "min_age": 12}


def performance_id(item):
    return get_performance_id(item["venue"], datetime.fromisoformat(item["start"]))


def test_read_routes_and_contract_filters(api_client):
    client, _, original = api_client
    festival = client.get("/api/festival")
    venues = client.get("/api/venues")
    artists = client.get("/api/artists")
    assert festival.status_code == 200 and festival.json()["days"]
    assert venues.status_code == 200 and venues.json()[0]["slug"]
    assert artists.status_code == 200
    assert [a["name"].casefold() for a in artists.json()] == sorted(a["name"].casefold() for a in artists.json())

    all_programme = client.get("/api/programme")
    day = client.get("/api/programme", params={"day": "2027-06-11"})
    venue = client.get("/api/programme", params={"venue": "le-kiosque"})
    both = client.get("/api/programme", params={"day": "2027-06-11", "venue": "le-kiosque"})
    assert all_programme.status_code == day.status_code == venue.status_code == both.status_code == 200
    assert all(p["festival_day"] == "2027-06-11" for p in day.json())
    assert all(p["venue"] == "le-kiosque" for p in venue.json())
    assert all(p["festival_day"] == "2027-06-11" and p["venue"] == "le-kiosque" for p in both.json())
    assert client.get("/api/programme", params={"venue": "unknown"}).status_code == 404
    assert client.get("/api/programme", params={"day": "June 11"}).status_code == 422

    artist = artists.json()[0]
    artist_detail = client.get(f"/api/artists/{artist['slug']}")
    assert artist_detail.status_code == 200 and "performances" in artist_detail.json()
    assert client.get("/api/artists/no-such-artist").status_code == 404

    first = all_programme.json()[0]
    detail = client.get(f"/api/performances/{first['id']}")
    assert detail.status_code == 200 and detail.json()["id"] == first["id"]
    assert client.get("/api/performances/no-such-performance").status_code == 404
    now = client.get("/api/now", params={"at": "2027-06-11T21:00"})
    assert now.status_code == 200
    assert now.json()["at"] == "2027-06-11T21:00"
    assert len(now.json()["up_next"]) <= 3


def test_create_performance_and_invalid_kind_unknown_venue_artist(api_client):
    client, storage, original = api_client
    created = client.post("/api/performances", json=solo_body())
    assert created.status_code == 201, created.text
    assert created.json()["id"] == "le-kiosque-2027-06-13-1000"
    assert client.get(f"/api/performances/{created.json()['id']}").status_code == 200
    assert len(storage.load()["performances"]) == len(original["performances"]) + 1

    invalid_kind = client.post("/api/performances", json={**solo_body(start="2027-06-13T12:00"), "kind": "invalid"})
    assert invalid_kind.status_code == 422
    assert client.post("/api/performances", json={**solo_body(start="2027-06-13T12:00"), "venue": "unknown"}).status_code == 404
    assert client.post("/api/performances", json={**solo_body(start="2027-06-13T12:00"), "artist": "unknown"}).status_code == 404
    assert client.post("/api/performances", json={"kind": "solo"}).status_code == 422


@pytest.mark.parametrize("min_age", [-1, 19])
def test_invalid_solo_min_age_is_422(api_client, min_age):
    client, _, _ = api_client
    assert client.post("/api/performances", json={**solo_body(), "min_age": min_age}).status_code == 422


def test_lineup_validation_and_artist_creation_errors(api_client):
    client, _, _ = api_client
    lineup = {"kind": "lineup", "title": "Lineup", "venue": "le-kiosque", "start": "2027-06-13T10:00", "duration_minutes": 60, "host": "paul-kerbrat", "acts": ["nora-lebrun"]}
    assert client.post("/api/performances", json=lineup).status_code == 422
    assert client.post("/api/artists", json={"name": "  "}).status_code == 422
    assert client.post("/api/artists", json={"name": "Zoé Tanguy"}).status_code == 201
    assert client.post("/api/artists", json={"name": "zoe tanguy"}).status_code == 409


def test_duration_and_out_of_festival_date_errors(api_client):
    client, _, _ = api_client
    assert client.post("/api/performances", json={**solo_body(), "duration_minutes": 0}).status_code == 422
    assert client.post("/api/performances", json={**solo_body(), "duration_minutes": 361}).status_code == 422
    assert client.post("/api/performances", json={**solo_body(start="2027-07-01T10:00")}).status_code == 409


def test_venue_and_artist_conflicts_plus_15_minute_gap(api_client):
    client, _, _ = api_client
    first = client.post("/api/performances", json=solo_body(start="2027-06-13T10:00"))
    assert first.status_code == 201, first.text
    assert client.post("/api/performances", json=solo_body(start="2027-06-13T10:29", title="Overlap")).status_code == 409
    # Exactly 15 minutes after the first show is accepted in the same venue.
    assert client.post("/api/performances", json=solo_body(start="2027-06-13T10:45", title="Next show")).status_code == 201
    # Nora is busy at the first time even in a different venue.
    assert client.post("/api/performances", json=solo_body(venue="grand-casino", start="2027-06-13T10:30", title="Nora elsewhere")).status_code == 409


def test_put_changes_id_and_failed_put_changes_nothing(api_client):
    client, storage, _ = api_client
    created = client.post("/api/performances", json=solo_body(start="2027-06-13T10:00"))
    assert created.status_code == 201, created.text
    old_id = created.json()["id"]
    moved = client.put(f"/api/performances/{old_id}", json=solo_body(start="2027-06-13T12:00", title="Moved"))
    assert moved.status_code == 200, moved.text
    new_id = moved.json()["id"]
    assert new_id != old_id and new_id == "le-kiosque-2027-06-13-1200"
    assert client.get(f"/api/performances/{old_id}").status_code == 404
    assert client.get(f"/api/performances/{new_id}").json()["title"] == "Moved"

    before = copy.deepcopy(storage.load())
    refused = client.put(f"/api/performances/{new_id}", json=solo_body(start="2027-06-13T15:00", title="Should not persist"))
    assert refused.status_code == 409
    assert storage.load() == before
    assert client.get(f"/api/performances/{new_id}").json()["start"] == "2027-06-13T12:00"
    assert client.put("/api/performances/no-such-id", json=solo_body()).status_code == 404


def test_workshop_registration_full_duplicate_and_wrong_kind(api_client):
    client, storage, _ = api_client
    workshop = next(p for p in storage.load()["performances"] if p["kind"] == "workshop")
    workshop_id = performance_id(workshop)
    # A participant can register if a place remains.
    current = client.get(f"/api/performances/{workshop_id}")
    assert current.status_code == 200
    current_count = len(current.json()["participants"])
    capacity = current.json()["max_participants"]
    if current_count < capacity:
        response = client.post(f"/api/performances/{workshop_id}/participants", json={"name": "Contract Tester"})
        assert response.status_code == 201, response.text
        assert "Contract Tester" in response.json()["participants"]
        assert client.post(f"/api/performances/{workshop_id}/participants", json={"name": "contract tester"}).status_code == 409

    # Wrong performance kind and missing performance use contract status codes.
    solo = next(p for p in storage.load()["performances"] if p["kind"] == "solo")
    solo_id = performance_id(solo)
    assert client.post(f"/api/performances/{solo_id}/participants", json={"name": "Alex"}).status_code == 422
    assert client.post("/api/performances/missing/participants", json={"name": "Alex"}).status_code == 404
    assert client.post(f"/api/performances/{workshop_id}/participants", json={"name": " "}).status_code == 422


def test_delete_twice(api_client):
    client, _, _ = api_client
    created = client.post("/api/performances", json=solo_body())
    performance_id_value = created.json()["id"]
    deleted = client.delete(f"/api/performances/{performance_id_value}")
    assert deleted.status_code == 204
    assert client.delete(f"/api/performances/{performance_id_value}").status_code == 404


def test_failed_save_returns_500_and_rolls_back(source_data):
    client = TestClient(create_app(FailingSaveStorage(copy.deepcopy(source_data))))
    before = client.get("/api/programme").json()
    response = client.post("/api/artists", json={"name": "Cannot Save"})
    assert response.status_code == 500
    assert client.get("/api/programme").json() == before
    assert client.get("/api/artists/no-such-artist").status_code == 404


def test_failed_read_returns_500():
    client = TestClient(create_app(FailingLoadStorage()))
    response = client.get("/api/festival")
    assert response.status_code == 500
    assert response.json() == {"detail": "The festival data file could not be read."}


def test_admin_and_public_pages_are_served(api_client):
    client, _, _ = api_client
    assert client.get("/admin/").status_code == 200
    assert client.get("/").status_code == 200


def test_each_app_has_independent_storage(source_data):
    first_storage = MemoryStorage(copy.deepcopy(source_data))
    second_storage = MemoryStorage(copy.deepcopy(source_data))
    first = TestClient(create_app(first_storage))
    second = TestClient(create_app(second_storage))
    created = first.post("/api/artists", json={"name": "Only in first app"})
    assert created.status_code == 201
    assert first.get("/api/artists/only-in-first-app").status_code == 200
    assert second.get("/api/artists/only-in-first-app").status_code == 404
    assert all(a["name"] != "Only in first app" for a in second.get("/api/artists").json())


def test_data_festival_file_is_not_changed_by_http_tests(source_data):
    # The test uses a memory copy, never a JsonStorage pointing at the project data file.
    original_bytes = DATA_FILE.read_bytes()
    client = TestClient(create_app(MemoryStorage(copy.deepcopy(source_data))))
    assert client.get("/api/festival").status_code == 200
    assert client.post("/api/artists", json={"name": "Ephemeral Artist"}).status_code == 201
    assert DATA_FILE.read_bytes() == original_bytes


def test_full_workshop_returns_409(source_data):
    workshop = next(item for item in source_data["performances"] if item["kind"] == "workshop")
    workshop["max_participants"] = len(workshop.get("participants", []))
    client = TestClient(create_app(MemoryStorage(copy.deepcopy(source_data))))
    workshop_id = performance_id(workshop)
    response = client.post(f"/api/performances/{workshop_id}/participants", json={"name": "One More Person"})
    assert response.status_code == 409
    assert response.json() == {"detail": "Workshop is full."}


def test_failed_performance_write_returns_500_without_changing_storage(source_data):
    storage = FailingSaveStorage(copy.deepcopy(source_data))
    client = TestClient(create_app(storage))
    before = storage.load()
    response = client.post("/api/performances", json=solo_body())
    assert response.status_code == 500
    assert storage.load() == before


def test_missing_kind_specific_field_is_fastapi_422_list(api_client):
    client, _, _ = api_client
    response = client.post("/api/performances", json={
        "kind": "solo", "title": "Missing artist", "venue": "le-kiosque",
        "start": "2027-06-13T10:00", "duration_minutes": 30,
    })
    assert response.status_code == 422
    assert isinstance(response.json()["detail"], list)
