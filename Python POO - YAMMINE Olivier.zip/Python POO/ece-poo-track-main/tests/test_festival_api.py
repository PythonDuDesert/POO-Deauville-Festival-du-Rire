"""Tests HTTP des règles métier de l’API du festival.

À placer dans tests/ puis lancer avec : uv run pytest -q
Ces tests utilisent une copie temporaire de festival.json : les données réelles
du projet ne sont pas modifiées.
"""
import copy
import importlib
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


@pytest.fixture
def api_client(tmp_path, monkeypatch):
    # Importer les modules après avoir rendu la racine accessible.
    models = importlib.import_module("festival_models")
    api = importlib.import_module("api")

    original_data = copy.deepcopy(api.festival)
    data_path = tmp_path / "festival.json"
    data_path.write_text(__import__("json").dumps(original_data, ensure_ascii=False), encoding="utf-8")

    monkeypatch.setattr(api, "DATA_FILE", data_path)
    from storage import JsonStorage
    monkeypatch.setattr(api, "storage", JsonStorage(data_path))
    monkeypatch.setattr(api, "festival", copy.deepcopy(original_data))
    monkeypatch.setattr(api, "festival_objects", models.load_festival(copy.deepcopy(original_data)))

    with TestClient(api.app) as client:
        yield client, api


def valid_solo(api, *, start="2027-06-13T10:00", title="API test solo", artist=None):
    artist = artist or api.festival["artists"][0]
    return {
        "kind": "solo",
        "title": title,
        "venue": "le-kiosque",
        "start": start,
        "duration_minutes": 30,
        "artist": api.name_to_slug(artist["name"]),
        "min_age": 12,
    }


def test_create_performance_rejects_invalid_kind(api_client):
    client, _ = api_client
    response = client.post("/api/performances", json={
        "kind": "unknown", "title": "Bad", "venue": "le-kiosque",
        "start": "2027-06-13T10:00", "duration_minutes": 30,
    })
    assert response.status_code == 422
    assert response.json()["detail"] == "Invalid performance kind."


@pytest.mark.parametrize("min_age", [-1, 19])
def test_create_solo_rejects_invalid_min_age(api_client, min_age):
    client, api = api_client
    body = valid_solo(api)
    body["min_age"] = min_age
    response = client.post("/api/performances", json=body)
    # API.md classe une valeur invalide en 422.
    assert response.status_code == 422


def test_create_lineup_rejects_fewer_than_two_acts(api_client):
    client, api = api_client
    host = api.festival["artists"][0]
    act = api.festival["artists"][1]
    response = client.post("/api/performances", json={
        "kind": "lineup", "title": "Invalid lineup", "venue": "le-kiosque",
        "start": "2027-06-13T10:00", "duration_minutes": 60,
        "host": api.name_to_slug(host["name"]),
        "acts": [api.name_to_slug(act["name"])],
    })
    assert response.status_code == 422


def test_create_workshop_with_non_positive_limit_is_rejected(api_client):
    client, api = api_client
    teacher = api.festival["artists"][0]
    response = client.post("/api/performances", json={
        "kind": "workshop", "title": "Invalid workshop", "venue": "le-kiosque",
        "start": "2027-06-13T10:00", "duration_minutes": 60,
        "teacher": api.name_to_slug(teacher["name"]), "max_participants": 0,
    })
    assert response.status_code == 422


def test_create_performance_with_unknown_venue_returns_404(api_client):
    client, api = api_client
    body = valid_solo(api)
    body["venue"] = "venue-inconnue"
    response = client.post("/api/performances", json=body)
    assert response.status_code == 404


def test_register_participant_on_non_workshop_returns_422(api_client):
    client, api = api_client
    item = next(item for item in api.festival["performances"] if item["kind"] == "solo")
    performance_id = api.get_performance_id(item["venue"], __import__("datetime").datetime.fromisoformat(item["start"]))
    response = client.post(f"/api/performances/{performance_id}/participants", json={"name": "Alex"})
    assert response.status_code == 422


def test_register_participant_on_unknown_performance_returns_404(api_client):
    client, _ = api_client
    response = client.post("/api/performances/no-such-performance/participants", json={"name": "Alex"})
    assert response.status_code == 404


def test_delete_unknown_performance_returns_404(api_client):
    client, _ = api_client
    response = client.delete("/api/performances/no-such-performance")
    assert response.status_code == 404


def test_update_unknown_performance_returns_404(api_client):
    client, api = api_client
    body = valid_solo(api)
    response = client.put("/api/performances/no-such-performance", json=body)
    assert response.status_code == 404


def test_invalid_update_keeps_original_performance(api_client):
    client, api = api_client
    existing = next(item for item in api.festival["performances"] if item["kind"] == "solo")
    original = copy.deepcopy(existing)
    performance_id = api.get_performance_id(
        existing["venue"], __import__("datetime").datetime.fromisoformat(existing["start"])
    )
    body = {
        "kind": "lineup", "title": "Invalid replacement", "venue": "le-kiosque",
        "start": "2027-06-13T10:00", "duration_minutes": 20,
        "host": api.name_to_slug(api.festival["artists"][0]["name"]),
        "acts": [api.name_to_slug(api.festival["artists"][1]["name"])],
    }
    response = client.put(f"/api/performances/{performance_id}", json=body)
    assert response.status_code in (409, 422)
    assert existing == original


def test_admin_solo_conflicts_and_failed_move_is_atomic(api_client):
    client, api = api_client
    body = {
        "kind": "solo", "title": "Nora at the Kiosk", "venue": "le-kiosque",
        "start": "2027-06-13T11:00", "duration_minutes": 45,
        "artist": "nora-lebrun", "min_age": 0,
    }
    created = client.post("/api/performances", json=body)
    assert created.status_code == 201, created.text
    first_id = created.json()["id"]
    assert first_id == "le-kiosque-2027-06-13-1100"

    # Same stage, overlapping time: the request is refused.
    overlapping = {**body, "start": "2027-06-13T11:30", "title": "Overlap"}
    refused = client.post("/api/performances", json=overlapping)
    assert refused.status_code == 409
    assert "occupied" in refused.json()["detail"].lower()

    # Nora is already on stage, even if the second show uses another venue.
    other_venue = {**body, "venue": "grand-casino", "start": "2027-06-13T11:30"}
    refused = client.post("/api/performances", json=other_venue)
    assert refused.status_code == 409
    assert "artist" in refused.json()["detail"].lower()

    moved_body = {**body, "start": "2027-06-13T12:00"}
    moved = client.put(f"/api/performances/{first_id}", json=moved_body)
    assert moved.status_code == 200, moved.text
    moved_id = moved.json()["id"]
    assert moved_id == "le-kiosque-2027-06-13-1200"

    # Maya Choukri occupies Le Kiosque at 15:00. A failed PUT must leave
    # the already-moved show at noon under its new ID.
    bad_move = {**body, "start": "2027-06-13T15:00"}
    refused = client.put(f"/api/performances/{moved_id}", json=bad_move)
    assert refused.status_code == 409
    still_there = client.get(f"/api/performances/{moved_id}")
    assert still_there.status_code == 200
    assert still_there.json()["start"] == "2027-06-13T12:00"
    assert client.get(f"/api/performances/{first_id}").status_code == 404


def test_duplicate_artist_names_are_rejected_case_insensitively(api_client):
    client, _ = api_client
    first = client.post("/api/artists", json={"name": "Zoé Tanguy"})
    assert first.status_code == 201
    second = client.post("/api/artists", json={"name": "zoe tanguy"})
    assert second.status_code == 409


def test_duplicate_workshop_participant_is_rejected(api_client):
    client, _ = api_client
    performance_id = "la-cabane-2027-06-12-1030"
    first = client.post(
        f"/api/performances/{performance_id}/participants", json={"name": "Test Person"}
    )
    assert first.status_code == 201, first.text
    second = client.post(
        f"/api/performances/{performance_id}/participants", json={"name": "Test Person"}
    )
    assert second.status_code == 409


def test_admin_page_is_served_from_project_web_directory(api_client):
    client, _ = api_client
    response = client.get("/admin/")
    assert response.status_code == 200
    assert "admin" in response.text.lower()
