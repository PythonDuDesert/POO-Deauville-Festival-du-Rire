"""Tests ciblés des règles métier du festival.

À placer à côté de festival_models.py et à lancer avec :
    uv run pytest -q
"""

import pytest

from festival_models import Artist, Festival, Lineup, SoloShow, Venue, Workshop


@pytest.fixture
def objects():
    venue = Venue("Le Kiosque", "le-kiosque", 5, "Beach promenade")
    host = Artist("Tom Vasseur", "tom-vasseur", "", "")
    artist_a = Artist("Nora Lebrun", "nora-lebrun", "", "")
    artist_b = Artist("Max Pellerin", "max-pellerin", "", "")
    teacher = Artist("Camille Martin", "camille-martin", "", "")
    return venue, host, artist_a, artist_b, teacher


def make_festival(venue, performances=None):
    return Festival(
        "Festival du Rire",
        "2027-06-10",
        "2027-06-13",
        venues=[venue],
        performances=performances or [],
    )


def make_solo(venue, artist, min_age=0):
    return SoloShow(
        id="solo-test",
        title="Solo test",
        venue=venue,
        start="2027-06-11T20:00",
        duration_minutes=30,
        description="",
        artist=artist,
        min_age=min_age,
    )


@pytest.mark.parametrize("min_age", [0, 1, 18])
def test_solo_accepts_min_age_between_zero_and_eighteen(objects, min_age):
    venue, _, artist, _, _ = objects
    make_festival(venue).add_performance(make_solo(venue, artist, min_age))


@pytest.mark.parametrize("min_age", [-1, 19])
def test_solo_rejects_min_age_outside_range(objects, min_age):
    venue, _, artist, _, _ = objects
    with pytest.raises(ValueError, match="Minimum age"):
        make_festival(venue).add_performance(make_solo(venue, artist, min_age))


def test_lineup_requires_at_least_two_acts(objects):
    venue, host, artist_a, _, _ = objects
    lineup = Lineup(
        id="lineup-test",
        title="Gala",
        venue=venue,
        start="2027-06-11T20:00",
        duration_minutes=30,
        description="",
        host=host,
        acts=[artist_a],
    )
    with pytest.raises(ValueError, match="at least two acts"):
        make_festival(venue).add_performance(lineup)


def test_lineup_rejects_duplicate_acts(objects):
    venue, host, artist_a, _, _ = objects
    lineup = Lineup(
        id="lineup-test",
        title="Gala",
        venue=venue,
        start="2027-06-11T20:00",
        duration_minutes=30,
        description="",
        host=host,
        acts=[artist_a, artist_a],
    )
    with pytest.raises(ValueError, match="unique"):
        make_festival(venue).add_performance(lineup)


def test_lineup_rejects_host_as_an_act(objects):
    venue, host, _, artist_b, _ = objects
    lineup = Lineup(
        id="lineup-test",
        title="Gala",
        venue=venue,
        start="2027-06-11T20:00",
        duration_minutes=30,
        description="",
        host=host,
        acts=[host, artist_b],
    )
    with pytest.raises(ValueError, match="host"):
        make_festival(venue).add_performance(lineup)


def test_lineup_requires_ten_minutes_per_act_and_three_between_acts(objects):
    venue, host, artist_a, artist_b, _ = objects
    # Deux actes nécessitent 10 + 3 + 10 = 23 minutes.
    lineup = Lineup(
        id="lineup-test",
        title="Gala",
        venue=venue,
        start="2027-06-11T20:00",
        duration_minutes=22,
        description="",
        host=host,
        acts=[artist_a, artist_b],
    )
    with pytest.raises(ValueError, match="duration is too short"):
        make_festival(venue).add_performance(lineup)


def test_lineup_at_minimum_duration_is_accepted(objects):
    venue, host, artist_a, artist_b, _ = objects
    lineup = Lineup(
        id="lineup-test",
        title="Gala",
        venue=venue,
        start="2027-06-11T20:00",
        duration_minutes=23,
        description="",
        host=host,
        acts=[artist_a, artist_b],
    )
    make_festival(venue).add_performance(lineup)


def test_workshop_capacity_is_limited_by_venue(objects):
    venue, _, _, _, teacher = objects
    workshop = Workshop(
        id="workshop-test",
        title="Atelier",
        venue=venue,
        start="2027-06-11T14:00",
        duration_minutes=60,
        description="",
        teacher=teacher,
        max_participants=10,
    )
    view = workshop.to_view()
    assert view["capacity"] == 5
    assert view["places_left"] == 5


def test_workshop_capacity_is_limited_by_max_participants(objects):
    venue, _, _, _, teacher = objects
    workshop = Workshop(
        id="workshop-test",
        title="Atelier",
        venue=venue,
        start="2027-06-11T14:00",
        duration_minutes=60,
        description="",
        teacher=teacher,
        max_participants=3,
    )
    assert workshop.to_view()["capacity"] == 3
    assert workshop.to_view()["places_left"] == 3


def test_workshop_rejects_non_positive_participant_limit(objects):
    venue, _, _, _, teacher = objects
    for limit in (0, -1):
        workshop = Workshop(
            id="workshop-test",
            title="Atelier",
            venue=venue,
            start="2027-06-11T14:00",
            duration_minutes=60,
            description="",
            teacher=teacher,
            max_participants=limit,
        )
        with pytest.raises(ValueError, match="Participant limit"):
            make_festival(venue).add_performance(workshop)


def test_workshop_registration_and_full_capacity(objects):
    venue, _, _, _, teacher = objects
    workshop = Workshop(
        id="workshop-test",
        title="Atelier",
        venue=venue,
        start="2027-06-11T14:00",
        duration_minutes=60,
        description="",
        teacher=teacher,
        max_participants=2,
    )
    workshop.register_participant(" Alice ")
    workshop.register_participant("Bob")
    assert workshop.participants == ["Alice", "Bob"]
    assert workshop.to_view()["places_left"] == 0
    with pytest.raises(ValueError, match="full"):
        workshop.register_participant("Charlie")


@pytest.mark.parametrize("name", ["", "   "])
def test_workshop_rejects_empty_participant_name(objects, name):
    venue, _, _, _, teacher = objects
    workshop = Workshop(
        id="workshop-test",
        title="Atelier",
        venue=venue,
        start="2027-06-11T14:00",
        duration_minutes=60,
        description="",
        teacher=teacher,
        max_participants=2,
    )
    with pytest.raises(ValueError, match="empty"):
        workshop.register_participant(name)


def test_each_performance_view_has_common_and_specific_fields(objects):
    venue, host, artist_a, artist_b, teacher = objects
    solo = make_solo(venue, artist_a, 12)
    lineup = Lineup(
        id="lineup-test",
        title="Gala",
        venue=venue,
        start="2027-06-11T20:00",
        duration_minutes=23,
        description="",
        host=host,
        acts=[artist_a, artist_b],
    )
    workshop = Workshop(
        id="workshop-test",
        title="Atelier",
        venue=venue,
        start="2027-06-11T14:00",
        duration_minutes=60,
        description="",
        teacher=teacher,
        max_participants=3,
    )

    common_fields = {
        "id",
        "kind",
        "title",
        "venue",
        "venue_name",
        "festival_day",
        "start",
        "end",
        "duration_minutes",
        "description",
        "summary",
        "capacity",
        "artists",
    }
    for performance in (solo, lineup, workshop):
        view = performance.to_view()
        assert common_fields <= view.keys()
        assert isinstance(view["artists"], list)
        assert all(set(item) == {"slug", "name"} for item in view["artists"])

    assert {"artist", "min_age"} <= solo.to_view().keys()
    assert solo.to_view()["artist"] == artist_a.slug
    assert solo.to_view()["min_age"] == 12

    assert {"host", "acts"} <= lineup.to_view().keys()
    assert lineup.to_view()["host"] == host.slug
    assert lineup.to_view()["acts"] == [artist_a.slug, artist_b.slug]

    assert {
        "teacher",
        "max_participants",
        "participants",
        "places_left",
    } <= workshop.to_view().keys()
    assert workshop.to_view()["teacher"] == teacher.slug


def test_solo_view_matches_api_contract(objects):
    venue, _, artist, _, _ = objects
    view = make_solo(venue, artist, 12).to_view()

    assert view["summary"] == f"with {artist.name}"
    assert view["artists"] == [{"slug": artist.slug, "name": artist.name}]
    assert view["artist"] == artist.slug
    assert view["min_age"] == 12


def test_lineup_view_preserves_order_and_summary(objects):
    venue, host, artist_a, artist_b, _ = objects
    lineup = Lineup(
        id="lineup-test",
        title="Gala",
        venue=venue,
        start="2027-06-11T20:00",
        duration_minutes=23,
        description="",
        host=host,
        acts=[artist_a, artist_b],
    )

    view = lineup.to_view()

    assert view["summary"] == (
        f"hosted by {host.name}, with {artist_a.name}, {artist_b.name}"
    )
    assert view["artists"] == [
        {"slug": host.slug, "name": host.name},
        {"slug": artist_a.slug, "name": artist_a.name},
        {"slug": artist_b.slug, "name": artist_b.name},
    ]
    assert view["acts"] == [artist_a.slug, artist_b.slug]


def test_workshop_view_updates_places_left_after_registration(objects):
    venue, _, _, _, teacher = objects
    workshop = Workshop(
        id="workshop-test",
        title="Atelier",
        venue=venue,
        start="2027-06-11T14:00",
        duration_minutes=60,
        description="",
        teacher=teacher,
        max_participants=3,
    )
    workshop.register_participant("Alice")
    view = workshop.to_view()

    assert view["capacity"] == 3
    assert view["participants"] == ["Alice"]
    assert view["places_left"] == 2
    assert view["teacher"] == teacher.slug
    assert view["artists"] == [{"slug": teacher.slug, "name": teacher.name}]


def test_festival_day_changes_at_six_am(objects):
    venue, _, artist, _, _ = objects
    before_six = SoloShow(
        id="solo-before-six",
        title="After Hours",
        venue=venue,
        start="2027-06-12T05:59",
        duration_minutes=30,
        description="",
        artist=artist,
    )
    at_six = SoloShow(
        id="solo-at-six",
        title="Morning Show",
        venue=venue,
        start="2027-06-12T06:00",
        duration_minutes=30,
        description="",
        artist=artist,
    )

    assert before_six.to_view()["festival_day"] == "2027-06-11"
    assert at_six.to_view()["festival_day"] == "2027-06-12"


def test_festival_collections_and_nested_lists_are_copies(objects):
    venue, host, artist_a, artist_b, teacher = objects
    lineup = Lineup(
        id="lineup-test",
        title="Gala",
        venue=venue,
        start="2027-06-11T20:00",
        duration_minutes=23,
        description="",
        host=host,
        acts=[artist_a, artist_b],
    )
    workshop = Workshop(
        id="workshop-test",
        title="Atelier",
        venue=venue,
        start="2027-06-11T14:00",
        duration_minutes=60,
        description="",
        teacher=teacher,
        max_participants=3,
        participants=["Alice"],
    )
    festival = Festival(
        "Festival",
        "2027-06-10",
        "2027-06-13",
        venues=[venue],
        artists=[host, artist_a, artist_b, teacher],
    )
    festival.add_performance(lineup)
    festival.add_performance(workshop)

    festival.performances.clear()
    festival.artists.clear()
    lineup.acts.clear()
    workshop.participants.clear()

    assert festival.get_performance("lineup-test") is lineup
    assert festival.get_performance("workshop-test") is workshop
    assert len(festival.artists) > 0
    assert len(lineup.acts) == 2
    assert workshop.participants == ["Alice"]


def test_workshop_rejects_duplicate_participant(objects):
    venue, _, _, _, teacher = objects
    workshop = Workshop(
        id="workshop-test",
        title="Atelier",
        venue=venue,
        start="2027-06-11T14:00",
        duration_minutes=60,
        description="",
        teacher=teacher,
        max_participants=3,
    )
    workshop.register_participant("Alice")
    with pytest.raises(ValueError, match="already registered"):
        workshop.register_participant("alice")


def _solo_at(venue, artist, start, performance_id):
    return SoloShow(
        id=performance_id,
        title=performance_id,
        venue=venue,
        start=start,
        duration_minutes=30,
        description="",
        artist=artist,
    )


def test_same_venue_requires_fifteen_minutes_between_performances(objects):
    venue, _, artist_a, artist_b, _ = objects
    festival = make_festival(venue)
    festival.add_performance(_solo_at(venue, artist_a, "2027-06-11T20:00", "first"))

    with pytest.raises(ValueError, match="15 minutes.*same venue"):
        festival.add_performance(
            _solo_at(venue, artist_b, "2027-06-11T20:44", "too-soon")
        )


def test_same_venue_accepts_exactly_fifteen_minutes_gap(objects):
    venue, _, artist_a, artist_b, _ = objects
    festival = make_festival(venue)
    festival.add_performance(_solo_at(venue, artist_a, "2027-06-11T20:00", "first"))

    festival.add_performance(_solo_at(venue, artist_b, "2027-06-11T20:45", "second"))
    assert len(festival.performances) == 2


def test_same_artist_requires_fifteen_minutes_even_in_another_venue(objects):
    venue, _, artist_a, _, _ = objects
    other_venue = Venue("Le Théâtre", "le-theatre", 100, "Town centre")
    festival = Festival(
        "Festival du Rire",
        "2027-06-10",
        "2027-06-13",
        venues=[venue, other_venue],
    )
    festival.add_performance(_solo_at(venue, artist_a, "2027-06-11T20:00", "first"))

    with pytest.raises(ValueError, match="15 minutes.*same artist"):
        festival.add_performance(
            _solo_at(other_venue, artist_a, "2027-06-11T20:44", "too-soon")
        )


def test_performance_update_rejecting_short_gap_is_atomic(objects):
    venue, _, artist_a, artist_b, _ = objects
    festival = make_festival(venue)
    first = _solo_at(venue, artist_a, "2027-06-11T20:00", "first")
    second = _solo_at(venue, artist_b, "2027-06-11T21:00", "second")
    festival.add_performance(first)
    festival.add_performance(second)

    updated = _solo_at(venue, artist_b, "2027-06-11T20:44", "second")
    with pytest.raises(ValueError, match="15 minutes"):
        festival.update_performance("second", updated)

    assert festival.get_performance("second") is second
    assert second.start.isoformat(timespec="minutes") == "2027-06-11T21:00"
