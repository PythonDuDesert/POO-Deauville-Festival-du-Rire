# Deauville — Festival du Rire 2027

Application de programmation du Festival du Rire de Deauville, réalisée pour le projet ECE de programmation orientée objet. Elle propose un site public, une API HTTP et une interface d'administration. Le programme est stocké dans un fichier JSON.

## Prérequis et installation

- Python 3.12 ou 3.13 (versions déclarées dans `pyproject.toml`).
- [`uv`](https://docs.astral.sh/uv/) pour créer l'environnement, installer les dépendances et lancer les commandes.
- Git pour cloner le dépôt.

Depuis un nouveau dossier :

```bash
git clone <URL_DU_DEPOT>
cd ece-poo-track-main
uv sync
```

`uv sync` installe les dépendances de l'application et les outils de développement, puis installe la commande `deauville` déclarée dans `pyproject.toml`.

## Lancer l'application

### Afficher le programme dans le terminal

```bash
uv run deauville programme 2027-06-11
```

La date attend le format `AAAA-MM-JJ`.

### Lancer le site, l'API et l'administration

```bash
uv run deauville serve
```

Puis ouvrir :

- Site public : <http://127.0.0.1:8000/>
- Administration : <http://127.0.0.1:8000/admin/>
- Documentation interactive de l'API : <http://127.0.0.1:8000/docs>

Arrêter le serveur avec `Ctrl+C`.

### Utiliser un autre fichier de données

La commande accepte `--data` pour utiliser une autre copie du fichier JSON, sans modifier le fichier fourni avec le projet :

```bash
uv run deauville --data ./data/test-festival.json programme 2027-06-11
uv run deauville --data ./data/test-festival.json serve
```

Le fichier indiqué doit déjà exister et contenir des données au format attendu pour que l'application puisse le charger.

## Tests et qualité

Lancer les tests de l'API E12, puis toute la suite :

```bash
uv run pytest B5/side -v
uv run pytest -v
```

Vérifier le formatage et les règles Ruff, puis construire les distributions :

```bash
uv run ruff format .
uv run ruff check .
uv build
```

Les tests de l'API utilisent `TestClient` et un stockage injecté pour ne pas démarrer un serveur ni modifier `data/festival.json`. Ils vérifient notamment les filtres, les erreurs documentées dans `API.md`, les créations/modifications/suppressions, les ateliers complets, les écritures qui échouent et l'isolation de plusieurs applications.

## Structure du projet

Les modules Python applicatifs restent à la racine : le projet n'utilise pas de répertoire `src/`.

| Fichier ou dossier | Responsabilité et raison d'être |
| --- | --- |
| `cli.py` | Définit la commande `deauville`, analyse les arguments, choisit le fichier de données et démarre soit l'affichage terminal, soit le serveur. Il constitue le point d'entrée utilisateur. |
| `api.py` | Définit les modèles de requête Pydantic, les routes HTTP, la conversion entre données JSON et objets métier, la traduction des erreurs en réponses HTTP et la fabrique `create_app`. Le serveur et les tests peuvent créer chacun leur application. |
| `festival.py` | Contient les objets métier et les règles : `Festival`, `Venue`, `Artist`, `Performance` et ses trois spécialisations `SoloShow`, `Lineup` et `Workshop`. Les règles de durée, de dates, de ressources partagées et de battement entre représentations sont vérifiées ici, plutôt que dans l'interface web. |
| `festival.py` — erreurs | `FestivalError` est l'erreur métier de base. `FestivalNotFound`, `FestivalConflict` et `FestivalInvalid` distinguent respectivement les ressources absentes, les conflits et les valeurs invalides. |
| `storage.py` | Sépare la persistance du métier grâce à l'interface abstraite `Storage`. `JsonStorage` lit et écrit le fichier JSON ; `MemoryStorage` conserve une copie en mémoire pour les tests et les exécutions isolées. |
| `festival_models.py` | Réexporte les classes historiques de modèles pour préserver la compatibilité avec les étapes précédentes du projet. Le code métier principal est dans `festival.py`. |
| `data/festival.json` | Données initiales du festival : lieux, artistes et représentations. |
| `web/public/` | HTML, CSS et JavaScript du site public. |
| `web/admin/` | HTML, CSS et JavaScript de l'interface d'administration. |
| `API.md` | Contrat HTTP : routes, champs, filtres, règles et erreurs attendues. |
| `tests/` | Tests du modèle métier, du stockage, de la CLI et de l'API. |
| `B1/` à `B5/` | Exercices et étapes pédagogiques conservés dans le dépôt. `B5/side/` contient notamment les tests de l'exercice E12. |

## Comment une règle métier répond à une requête

Exemple : `POST /api/performances`.

1. FastAPI reçoit la requête HTTP et valide la forme du JSON avec `PerformanceCreate`.
2. `create_performance` dans `api.py` prépare la représentation à sauvegarder et construit l'objet métier avec `_build_performance_object`.
3. `Festival.add_performance` et les validations du modèle dans `festival.py` vérifient les règles métier : type de représentation, durée, dates, salle, artistes et intervalle minimal.
4. Une réussite est enregistrée par `Storage.save`; la réponse HTTP contient la représentation normalisée. Si la validation échoue, la route ne sauvegarde pas le changement.
5. Les erreurs métier héritent de `FestivalError`. Le gestionnaire d'exception de `api.py` utilise leur `status_code` et leur message pour répondre sous la forme `{"detail": "..."}`. Les corps de requête mal formés sont traités par FastAPI/Pydantic et renvoient également un statut 422, avec une liste de détails.

## Où se trouvent les règles ?

Les règles qui doivent rester vraies quelle que soit l'interface sont dans `festival.py`, notamment :

- les représentations ne peuvent pas se chevaucher dans une même salle ou pour un même artiste ;
- un battement d'au moins 15 minutes est exigé entre deux représentations qui partagent une salle ou un artiste ;
- une représentation doit respecter les dates du festival et les durées admises ;
- un plateau (`Lineup`) doit respecter ses contraintes d'artistes et de durée ;
- un atelier (`Workshop`) ne peut pas dépasser sa capacité et refuse les inscriptions en double.

`api.py` s'occupe du protocole HTTP, des paramètres, de la traduction des erreurs et de la sauvegarde. `web/` affiche et transmet les données, mais ne constitue pas l'autorité finale pour les règles métier.

## Que faudrait-il changer pour utiliser une base de données ?

L'interface `Storage` définit actuellement `load()` et `save()`. Une évolution possible serait d'ajouter une implémentation, par exemple `SqlStorage`, qui lit et écrit dans une base SQL, puis de l'injecter à `create_app` et à la CLI à la place de `JsonStorage`. Les routes et les règles métier pourraient ainsi rester largement séparées de la technologie de stockage.

En pratique, passer à une base de données demanderait aussi de définir le schéma et les relations (lieux, artistes, représentations, participants), les migrations, les transactions pour que les mises à jour restent atomiques, et la gestion des erreurs de connexion. Il faudrait décider si `load()`/`save()` reste une interface adaptée ou si le stockage devient un ensemble de méthodes de dépôt (`get`, `add`, `update`, `delete`). Ce deuxième choix éviterait de charger et réécrire tout le festival à chaque changement, mais nécessiterait de modifier les appels de `api.py` et les tests associés.

## État du projet

### Réalisé

- Site public, interface d'administration et API décrite dans `API.md`.
- Affichage du programme en ligne de commande.
- Modèle métier avec classes spécialisées pour les représentations et erreurs métier dédiées.
- Persistance JSON séparée derrière `Storage`, stockage mémoire pour les tests.
- Filtrage du programme par date et lieu, administration des artistes et représentations, inscription aux ateliers.
- Tests automatisés pour les règles métier, les routes HTTP, les erreurs de lecture/écriture et l'absence de modification du fichier de données pendant les tests.

### Non réalisé / limites connues

- Le stockage est un fichier JSON ; aucune base de données n'est configurée.
- Il n'y a pas d'authentification ni de gestion de rôles pour protéger l'interface d'administration : elle est prévue pour un usage local de démonstration.
- Le fuseau horaire n'est pas modélisé : les dates et heures sont interprétées comme l'heure locale du festival, conformément à `API.md`.
- La commande terminal affiche le programme directement depuis les données du stockage ; les règles de validation détaillées restent centralisées dans le modèle métier utilisé par l'API.
- La vérification finale du dépôt doit être refaite depuis un clone propre avec les commandes de la section « Tests et qualité », notamment Ruff et `uv build`.
