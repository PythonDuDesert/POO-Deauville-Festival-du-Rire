# Deauville — Festival du Rire 2027

Projet ECE Paris de programmation orientée objet : programme public, API et administration du Festival du Rire de Deauville.

## Installation et commandes

Depuis la racine du projet, avec `uv` installé :

```bash
uv sync
uv run deauville programme 2027-06-11
uv run deauville serve
uv run pytest
uv build
```

- Site public : <http://127.0.0.1:8000/>
- Administration : <http://127.0.0.1:8000/admin/>
- Documentation API : <http://127.0.0.1:8000/docs>

Pour utiliser une autre copie du fichier de données, placez `--data` avant la commande :

```bash
uv run deauville --data ./data/test-festival.json programme 2027-06-11
uv run deauville --data ./data/test-festival.json serve
```

## Structure (un seul dossier de projet)

```text
ece-poo-track-main/
  api.py              # routes FastAPI
  cli.py              # commandes deauville
  festival.py         # objets et règles métier
  festival_models.py  # compatibilité E10
  storage.py          # stockage JSON et mémoire
  data/festival.json  # données du festival
  web/public/         # site public
  web/admin/          # interface d’administration
  tests/              # tests automatisés
```

Les fichiers Python applicatifs sont directement à la racine du projet : aucun dossier `src/deauville/` n’est nécessaire. La commande `deauville` est installée par `uv sync`.

## Règle de planning (E10)

Deux représentations qui partagent une salle ou au moins un artiste doivent être séparées par **15 minutes minimum**, après la fin de la première représentation. Un écart de 14 minutes est refusé ; 15 minutes exactement est accepté. La validation est appliquée dans le modèle métier, y compris lors d’une modification, et une modification refusée laisse le planning inchangé.

Le code applicatif reste à la racine du projet. `create_app(storage)` construit une application FastAPI indépendante pour le serveur et pour les tests.

## Contrat API et tests (E12)

Les tests utilisent `TestClient` et un `MemoryStorage` distinct par application : ils ne démarrent pas de serveur et n'écrivent pas dans `data/festival.json`. Ils couvrent les routes de lecture et leurs filtres, les erreurs documentées dans `API.md`, les créations, les modifications atomiques, les ateliers complets, les suppressions répétées et les erreurs de lecture/écriture.

```bash
uv run pytest B5/side -v
uv run pytest -v
```

Les tests vérifient aussi que le fichier de données de référence reste inchangé.
