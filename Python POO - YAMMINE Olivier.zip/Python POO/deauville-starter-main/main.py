# Reads the data of the festival and prints its name.
# Run it from this folder: uv run main.py
#
# The three lines below open the file and turn its JSON text into Python
# dicts and lists. How they work is explained in step 05; for now, use them.


import sys

from festival import (
    add,
    artist_performances,
    artist_performances_display,
    bloc_one,
    cancel,
    prog_for_day,
    prog_for_now,
    venues,
)


def main() -> None:
    # sys.argv: the words typed after the file name.
    arguments = sys.argv[1:]
    if len(arguments) == 0:
        bloc_one()
    elif arguments == ["venues"]:
        venues()
    elif arguments[0] == "artist" and len(arguments) == 2:
        artist_performances_display(arguments[1], artist_performances(arguments[1]))
    elif arguments[0] == "programme" and len(arguments) == 2:
        prog_for_day(arguments[1])
    elif arguments[0] == "now" and len(arguments) == 2:
        prog_for_now(arguments[1])
    elif arguments[0] == "add":
        add()
    elif arguments[0] == "cancel":
        cancel(arguments[1])
    else:
        #print(__doc__)
        print("uv run main.py : the summary of step 00")
        print("uv run main.py venues : each venue with its slug and seats, the total")
        print("uv run main.py programme 2027-06-11 : the program of the day")
        print("uv run main.py artist max-pellerin : the performances of an artist, with the role")
        print("uv run main.py now 2027-06-11T18:00 : the current program displayed and the 3 next ones")
        print("uv run main.py add")
        print("uv run main.py cancel le-kiosque-2027-06-12-0100")


if __name__ == "__main__":
    main()