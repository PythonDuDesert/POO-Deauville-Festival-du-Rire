import json
import unicodedata
from datetime import datetime, timedelta
from pathlib import Path

DAY_CHANGE = 6

DATA_FILE = Path(__file__).parent / "data" / "festival.json"

with open("data/festival.json", encoding="utf-8") as file:
    festival = json.load(file)

# Bloc 1
def bloc_one():
    print(festival["name"])
    print("From ", festival["first_day"], " to ", festival["last_day"])
    print(len(festival["venues"]), " venues, ", len(festival["artists"]), " artists, ", len(festival["performances"]), " performances")

    total_seats = 0
    print("\n")
    print("Venues :")
    for element in festival["venues"]:
        print("- ", element["name"], ": ", element["capacity"], " seats (", element["address"], ")")
        total_seats += element["capacity"]
    print("Total: ", total_seats, " seats")

    dict_performances = {}
    for perf in festival["performances"]:
        if perf["kind"] not in dict_performances:
            dict_performances[perf["kind"]] = 1
        else:
            dict_performances[perf["kind"]] += 1
    print("\n")
    for e in dict_performances:
        print(e, ": ", dict_performances[e])

    print("\n")
    print("At Le Kiosque:")
    for perf in festival["performances"]:
        if perf["venue"] == "le-kiosque":
            print("- ", perf["start"], perf["title"])

    longest = festival["performances"][0]
    longest_duration = longest["duration_minutes"]
    for perf in festival["performances"]:
        if perf["duration_minutes"] > longest_duration:
            longest = perf
            longest_duration = perf["duration_minutes"]
    print("\n")
    print("Longest: ", longest["title"], "(", longest_duration, " min )")

    print("\n")
    for perf in festival["performances"]:
        if perf["kind"] == "workshop":
            print(f'{perf["title"]} on {perf["start"]}: {len(perf["participants"])}/{perf["max_participants"]} registered')

    dict_artists = {}
    for artists in festival["artists"]:
        name = artists["name"]
        name = name.lower().replace(" ", "-")
        name = name.replace("é", "e")
        name = name.replace("è", "e")
        if name not in dict_artists:
            dict_artists[name] = 0
    for perf in festival["performances"]:
        if perf["kind"] == "lineup":
            dict_artists[perf["host"]] += 1
            for a in perf["acts"]:
                dict_artists[a] += 1
        elif perf["kind"] == "workshop":
            dict_artists[perf["teacher"]] += 1
        else:
            dict_artists[perf["artist"]] += 1
    print("\n")
    nbr_max = 0
    for a in dict_artists:
        nbr_max = max(nbr_max, dict_artists[a])
    liste_max = []
    for b in dict_artists:
        if dict_artists[b] == nbr_max:
            liste_max.append(b)
    print("On stage", nbr_max, "times:", ", ".join(liste_max))

    print("\n")
    date = input("Day (YYYY-MM-DD): ")
    found = []
    for event in festival["performances"]:
        if event["start"][0:10] == date:
            found.append(event)
    if found == []:
        print(f'No performance on {date}.')
    else:
        for event in found:
            print(f'{event["start"][11:16]} | {event["venue"]} | {event["title"]} ({event["kind"]})')


# Bloc 2
def name_to_slug(name):
    decomposed = unicodedata.normalize("NFKD", name)
    slug_name = decomposed.encode("ascii", "ignore").decode("ascii")
    result = ""
    for char in slug_name.lower():
        if char.isalnum():
            result += char
        elif not result.endswith("-"):
            result += "-"
    return result

def slug_to_name(name):
    return name.replace("-", " ").strip().title()

def venues():
    for v in festival["venues"]:
        slug_name = name_to_slug(v["name"])
        print(f'{slug_name}: {v["name"]}, {v["capacity"]} seats')

def artist_performances(name):
    dict_apparition = {}
    i = 0
    for perf in festival["performances"]:
        if perf["kind"] == "lineup":
            if perf["host"] == name:
                dict_apparition[i] = "host"
            elif name in perf["acts"]:
                dict_apparition[i] = "act"
        elif perf["kind"] == "workshop":
            if perf["teacher"] == name:
                dict_apparition[i] = "teacher"
        else:
            if perf["artist"] == name:
                dict_apparition[i] = "solo"
        i += 1
    return dict_apparition

def artist_performances_display(name, dict_apparition):
    if len(dict_apparition) == 0:
        print(f'No artist "{name}".')
    print(name)
    for i in dict_apparition:
        perf_selected = festival["performances"][i]
        print(f'\n{text_to_date(perf_selected["start"][0:10]).strftime("%A %d")} {perf_selected["start"][11:16]} | {perf_selected["venue"]} | {perf_selected["title"]} ({dict_apparition[i]})')

def text_to_date(date):
    return datetime.fromisoformat(date)

def add_duration_to_text(time, delta):
    return datetime.fromisoformat(time) + timedelta(minutes=delta)

def add_duration(time, delta):
    return time + timedelta(minutes=delta)

def prog_for_day(date):
    list_event = []
    target_date = text_to_date(date).date()
    for event in festival["performances"]:
        event_date = text_to_date(event["start"]).date()
        if event_date == target_date or event_date == target_date+timedelta(days=1) and text_to_date(event["start"]).hour < 6: #Si jour de "date" ou si lendemain de "date" mais heure < 6h
            list_event.append(event)
    if len(list_event) == 0:
        print("No event for", text_to_date(date).strftime("%A %d %B"))
    else:
        print("Programme for", text_to_date(date).strftime("%A %d %B"), ":")
        for event in list_event:
            print(f'{event["start"][11:16]}-{add_duration_to_text(event["start"], event["duration_minutes"]).strftime("%H:%M")} | {slug_to_name(event["venue"])} | {event["title"]} ({event["kind"]})')

def prog_for_now(date):
    target_datetime = text_to_date(date)
    next_events = []
    for event in festival["performances"]:
        start = text_to_date(event["start"])
        end = start + timedelta(minutes=event["duration_minutes"])
        if len(next_events) == 4:
            prog_for_now_display(target_datetime, next_events)
            return
        if len(next_events) > 0 and len(next_events) < 4:
            next_events.append(event)
        if start <= target_datetime < end:
            next_events.append(event)
        
def prog_for_now_display(target_datetime, next_events):
    print(f'On stage at {target_datetime.date()} {target_datetime.strftime("%H:%M")}:')
    print(f'- {next_events[0]["title"]} at {slug_to_name(next_events[0]["venue"])}, until {add_duration_to_text(next_events[0]["start"], next_events[0]["duration_minutes"]).strftime("%H:%M")}')
    print("Up next:")
    for i in range(1, len(next_events)):
        print(f'- {next_events[i]["start"][11:16]}-{add_duration_to_text(next_events[i]["start"], next_events[i]["duration_minutes"]).strftime("%H:%M")} | {slug_to_name(next_events[i]["venue"])} | {next_events[i]["title"]} ({next_events[i]["kind"]})')

def add():
    title = input("Title : ")
    artist = input("Artist (slug): ")
    venue = input("Venue (slug): ")
    start = input("Start date&time (YYYY-MM-DDTHH:MM): ")
    duration = int(input("Duration (minutes): "))
    check_add(title, artist, venue, start, duration)

    performance = {
        "kind": "solo",
        "title": title,
        "artist": artist,
        "venue": venue,
        "start": start,
        "duration_minutes": duration
    }
    festival["performances"].append(performance)
    with DATA_FILE.open("w", encoding="utf-8") as file:
        json.dump(festival, file, ensure_ascii=False, indent=2)
    print(f'Added: "{title}".')

def check_add(title, artist, venue, start, duration):
    if not title.strip(): # Détecte les chaines vides
        raise ValueError("Title is empty !")
        
    is_artist_valid = False
    for artists in festival["artists"]:
        if artist == name_to_slug(artists["name"]):
            is_artist_valid = True
    if is_artist_valid == False:
        raise ValueError(f'{artist} is not in the artists list')
    
    is_venue_valid = False
    for venues in festival["venues"]:
        if venue == name_to_slug(venues["name"]):
            is_venue_valid = True
    if is_venue_valid == False:
        raise ValueError(f'{venue} is not in the venues list')
    
    if len(start) != 16 or start[10] != "T" or start[13] != ":":
        raise ValueError("Format invalid! Date must be YYYY-MM-DDTHH:MM.")
    start = text_to_date(start)
    if start.date() < text_to_date(festival["first_day"]).date() or start.date() > text_to_date(festival["last_day"]).date():
        raise ValueError(f'{start} is not a day of the festival.')
    
    if duration < 1 or duration > 360 or type(duration) != int:
        raise ValueError("Duration must be a number between 1 and 360 min.")

    for perf in festival["performances"]:
        if perf["title"] == title:
            raise ValueError("This title performance already exists !")
        if perf["venue"] == venue and check_spacing(start, duration, text_to_date(perf["start"]), perf["duration_minutes"]):
            raise ValueError(f'{venue} needs 30min between performances.')
        if performance_has_artist(perf, artist) and check_spacing(start, duration, text_to_date(perf["start"]), perf["duration_minutes"]):
            raise ValueError(f'{artist} needs 30min between performances.')   

def check_spacing(start1, duration1, start2, duration2):
    end1 = start1 + timedelta(minutes=duration1) # heure de fin du 1er spectacle
    end2 = start2 + timedelta(minutes=duration2) # heure de fin du 2e spectacle
    return start1 < end2 + timedelta(minutes=30) and start2 < end1 + timedelta(minutes=30) # Vérification des 30min d'espacement

def performance_has_artist(perf, artist):
    if perf["kind"] == "lineup":
        return perf["host"] == artist or artist in perf["acts"]
    elif perf["kind"] == "workshop":
        return perf["teacher"] == artist
    else:
        return perf["artist"] == artist

def cancel(performance_cancel):
    time_cancel = performance_cancel[-4:]
    day_cancel = performance_cancel[-15:-5]
    venue_cancel = performance_cancel[0:-16]
    for perf in festival["performances"]:
        if (perf["venue"] == venue_cancel and perf["start"][0:10] == day_cancel and perf["start"][11:16] == time_cancel):
            festival["performances"].remove(perf)
            with DATA_FILE.open("w", encoding="utf-8") as file:
                json.dump(festival, file, ensure_ascii=False, indent=2)
            print(f'{perf["title"]} has been cancelled.')
            return
    raise ValueError("Unkwown ID.")
