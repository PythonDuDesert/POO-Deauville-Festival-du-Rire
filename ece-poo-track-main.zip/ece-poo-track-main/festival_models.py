import json
import unicodedata
from datetime import datetime, timedelta
from pathlib import Path

DAY_CHANGE = 6

DATA_FILE = Path(__file__).parent / "data" / "festival.json"


class Venue:
    def __init__(self, name, slug, capacity, address):
        self.name = name
        self.slug = slug
        self.capacity = capacity
        self.address = address

class Artist:
    def __init__(self, name, slug, bio, photo_url):
        self.name = name
        self.slug = slug
        self.bio = bio
        self.photo_url = photo_url

class Performance:
    def __init__(self, id, kind, title, venue, start, duration_minutes, description, artist=None, min_age=None, host=None, acts=None, teacher=None, participants=None, max_participants=None):
        self.id = id
        self.kind = kind
        self.title = title
        self.venue = venue
        self.start = start
        self.duration_minutes = duration_minutes
        self.description = description
        self.artist = artist
        self.min_age = min_age
        self.host = host
        self.acts = acts if acts is not None else []
        self.teacher = teacher
        self.participants = participants if participants is not None else []
        self.max_participants = max_participants

    @property
    def end(self):
        start_datetime = datetime.fromisoformat(self.start)
        return start_datetime + timedelta(minutes=self.duration_minutes)

    @property
    def festival_day(self):
        start_datetime = datetime.fromisoformat(self.start)
        return start_datetime.date() if start_datetime.hour >= DAY_CHANGE else start_datetime.date() - timedelta(days=1)

    def involves(self, artist):
        if self.kind == "solo":
            return self.artist.slug == artist.slug
        elif self.kind == "lineup":
            return self.host.slug == artist.slug or any(act.slug == artist.slug for act in self.acts)
        else:
            return self.teacher.slug == artist.slug

    def to_view(self):
        if self.kind == "solo":
            artists = [self.artist]
        elif self.kind == "lineup":
            artists = [self.host] + self.acts
        elif self.kind == "workshop":
            artists = [self.teacher]
        else:
            artists = []
        if self.kind == "solo":
            summary = f"with {self.artist.name}"
        elif self.kind == "lineup":
            act_names = ", ".join(act.name for act in self.acts)
            summary = f"hosted by {self.host.name}, with {act_names}"
        elif self.kind == "workshop":
            summary = f"with {self.teacher.name}"
        else:
            summary = ""
        result = { # Commun
            "id": self.id,
            "kind": self.kind,
            "title": self.title,
            "venue": self.venue.slug,
            "venue_name": self.venue.name,
            "festival_day": self.festival_day.isoformat(),
            "start": self.start,
            "end": self.end.isoformat(timespec="minutes"),
            "duration_minutes": self.duration_minutes,
            "description": self.description,
            "artists": [
                {"slug": artist.slug, "name": artist.name}
                for artist in artists
            ],
            "summary": summary,
            "capacity": self.venue.capacity,
        }

        # Champs "optionnels", remplis selon lse cas
        if self.kind == "solo":
            result["artist"] = self.artist.slug
            result["min_age"] = self.min_age
        elif self.kind == "lineup":
            result["host"] = self.host.slug
            result["acts"] = [artist.slug for artist in self.acts]
        if self.max_participants is not None:
            result["places_left"] = max(0, self.max_participants - len(self.participants))
        else:
            result["places_left"] = None

        return result


def create_performance_id(venue, start):
    start_datetime = datetime.fromisoformat(start)
    date = start_datetime.strftime("%Y-%m-%d")
    time = start_datetime.strftime("%H%M")
    return f"{venue.slug}-{date}-{time}"

def load_festival():
    with DATA_FILE.open(encoding="utf-8") as file:
        festival = json.load(file)

    venues = [
        Venue(
            name=venue["name"],
            slug=name_to_slug(venue["name"]),
            capacity=venue["capacity"],
            address=venue["address"]
        )
        for venue in festival["venues"]
    ]

    artists = [
        Artist(
            name=artist["name"],
            slug=name_to_slug(artist["name"]),
            bio=artist["bio"],
            photo_url=artist["photo_url"]
        )
        for artist in festival["artists"]
    ]

    venues_by_slug = {venue.slug: venue for venue in venues}
    artists_by_slug = {artist.slug: artist for artist in artists}

    performances = []
    for perf in festival["performances"]:
        venue = venues_by_slug[perf["venue"]]
        if perf["kind"] == "solo":
            performance = Performance(
                id=create_performance_id(venue, perf["start"]),
                kind=perf["kind"],
                title=perf["title"],
                venue=venue,
                start=perf["start"],
                duration_minutes=perf["duration_minutes"],
                description=perf["description"],
                artist=artists_by_slug[perf["artist"]],
                min_age=perf["min_age"]
            )
        elif perf["kind"] == "lineup":
            performance = Performance(
                id=create_performance_id(venue, perf["start"]),
                kind=perf["kind"],
                title=perf["title"],
                venue=venue,
                start=perf["start"],
                duration_minutes=perf["duration_minutes"],
                description=perf["description"],
                host=artists_by_slug[perf["host"]],
                acts=[
                    artists_by_slug[slug]
                    for slug in perf["acts"]
                ]
            )
        elif perf["kind"] == "workshop":
            performance = Performance(
                id=create_performance_id(venue, perf["start"]),
                kind=perf["kind"],
                title=perf["title"],
                venue=venue,
                start=perf["start"],
                duration_minutes=perf["duration_minutes"],
                description=perf["description"],
                teacher=artists_by_slug[perf["teacher"]],
                participants=perf["participants"],
                max_participants=perf["max_participants"]
            )
        performances.append(performance)

    return {
        "name": festival["name"],
        "first_day": festival["first_day"],
        "last_day": festival["last_day"],
        "venues": venues,
        "artists": artists,
        "performances": performances,
    }


def name_to_slug(name):
    decomposed = unicodedata.normalize("NFKD", name)
    slug_name = decomposed.encode("ascii", "ignore").decode("ascii")
    result = ""
    for char in slug_name.lower():
        if char.isalnum():
            result += char
        elif not result.endswith("-"):
            result += "-"
    return result

def slug_to_name(name):
    return name.replace("-", " ").strip().title()


festival = load_festival()
